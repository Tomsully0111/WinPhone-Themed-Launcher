# Metro Launcher

A Windows Phone–style home screen for Android, written in Kotlin with Jetpack Compose.
It is an ordinary app, so it works on GrapheneOS without root or ROM changes.

## What works

Start screen
- Small, medium and wide tiles in your accent color, or see-through over a start background photo
- Tiles fly in when you come home and swing away when you open an app
- Long-press a tile to edit it: drag to move, ✕ to unpin, ⤢ to resize
- Drop a tile in the middle of another to make a folder; tap a folder to open it
- "Show more tiles" for three medium tiles across, and a light theme

Live tiles
- Tiles flip on their own rhythm; app tiles show notification counts (and optional previews)
- Clock, calendar (next event), music (now playing, with controls), photos (your picks) and people (contact mosaic)
- Live tiles can be turned off, and stay still when Android animations are off

App list
- Alphabetical list with jump grid, search, and "new" on recently installed apps
- Long-press an app to pin it, open app info or uninstall

## Privacy

- No internet permission: nothing the launcher reads can leave the phone
- Notification access (counts, previews, music) is off until you turn it on in Android settings
- Calendar and contacts are asked for only when you pin those tiles
- Photos come from Android's photo picker, so the launcher only ever sees the ones you choose

## Build and install

1. Open this folder in Android Studio (Ladybug or newer), or build with the GitHub workflow.
2. Install the APK, press Home and choose **Metro Launcher**.
