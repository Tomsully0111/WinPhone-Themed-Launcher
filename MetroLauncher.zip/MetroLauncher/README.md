# Metro Launcher

A Windows Phone–style home screen for Android, written in Kotlin with Jetpack Compose.
It is an ordinary app, so it works on GrapheneOS without root or ROM changes.

## What works

- Start screen of small, medium and wide tiles on a 4-column grid, in your accent color
- Long-press a tile to unpin, resize (small → medium → wide) or move it earlier/later
- A live clock-and-date tile
- Swipe left (or tap the arrow) for the alphabetical app list
- Tap a letter header for the jump grid; long-press an app to pin, open app info or uninstall
- Accent color picker with the classic Metro palette
- Work-profile apps show up too (with the profile badge)

## Build and install

1. Open this folder in Android Studio (Ladybug or newer). If it asks for a Gradle wrapper,
   let it create one, or run `gradle wrapper --gradle-version 8.9` here.
2. Run the `app` configuration on your phone with USB debugging on.
3. Press Home and choose **Metro Launcher**, or set it under
   Settings → Apps → Default apps → Home app.

## Good next steps

- Live tiles from notifications: a `NotificationListenerService` that counts unread
  notifications per app and shows the number on its tile
- Drag-to-rearrange tiles instead of the move buttons
- Selawik font (see the note in `ui/Theme.kt`)
- More built-in live tiles: calendar, weather, photos
