package dev.metro.launcher.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat

data class Person(val id: Long, val name: String, val photo: ImageBitmap?) {
    val initials: String
        get() = name.split(' ').mapNotNull { it.firstOrNull() }.take(2).joinToString("").uppercase()
}

/** Reads names and thumbnail photos for the people tile. Held in memory only. */
class PeopleRepository(private val context: Context) {

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    fun load(limit: Int = 36): List<Person> {
        if (!hasPermission()) return emptyList()
        data class Row(val id: Long, val name: String, val thumb: String?, val starred: Boolean)

        val rows = ArrayList<Row>()
        runCatching {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                    ContactsContract.Contacts.PHOTO_THUMBNAIL_URI,
                    ContactsContract.Contacts.STARRED,
                ),
                null,
                null,
                "${ContactsContract.Contacts.STARRED} DESC",
            )?.use { c ->
                while (c.moveToNext() && rows.size < 300) {
                    val name = c.getString(1)?.takeIf { it.isNotBlank() } ?: continue
                    rows += Row(c.getLong(0), name, c.getString(2), c.getInt(3) == 1)
                }
            }
        }

        // Favorites first, then people with photos, which make the best mosaic.
        return rows
            .sortedWith(compareByDescending<Row> { it.starred }.thenByDescending { it.thumb != null })
            .take(limit)
            .map { row ->
                val photo = row.thumb?.let { uri ->
                    runCatching {
                        context.contentResolver.openInputStream(Uri.parse(uri))?.use {
                            BitmapFactory.decodeStream(it)?.asImageBitmap()
                        }
                    }.getOrNull()
                }
                Person(row.id, row.name, photo)
            }
    }
}
