package dev.metro.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import kotlin.random.Random

// Quick start, soft landing: close to the Windows Phone flip curve.
private val FlipEasing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)
private val FlipSpec = tween<Float>(durationMillis = 700, easing = FlipEasing)

/**
 * A two-sided tile that flips top-over-bottom on its horizontal axis, like Windows Phone live tiles.
 *
 * Each tile gets its own random rhythm from [seed], so a start screen full of tiles
 * flips one at a time instead of all at once. Turning [live] off flips back to the front.
 */
@Composable
fun FlipFaces(
    live: Boolean,
    seed: Int,
    frontDwellMs: LongRange,
    backDwellMs: LongRange,
    modifier: Modifier = Modifier,
    front: @Composable () -> Unit,
    back: @Composable () -> Unit,
) {
    val rotation = remember { Animatable(0f) }

    LaunchedEffect(live, seed, frontDwellMs, backDwellMs) {
        // Finish any flip in progress by landing on the front face.
        if (rotation.value != 0f) {
            if (rotation.value > 180f) {
                rotation.animateTo(360f, tween(350, easing = FlipEasing))
                rotation.snapTo(0f)
            } else {
                rotation.animateTo(0f, tween(350, easing = FlipEasing))
            }
        }
        if (!live) return@LaunchedEffect
        val random = Random(seed)
        // Stagger the first flip so tiles don't move together.
        delay(random.nextLong(1_000L, frontDwellMs.last))
        while (true) {
            rotation.animateTo(180f, FlipSpec)
            delay(random.nextLong(backDwellMs.first, backDwellMs.last))
            rotation.animateTo(360f, FlipSpec)
            rotation.snapTo(0f)
            delay(random.nextLong(frontDwellMs.first, frontDwellMs.last))
        }
    }

    val angle = rotation.value
    val showBack = angle > 90f && angle < 270f

    Box(
        modifier.graphicsLayer {
            rotationX = angle
            cameraDistance = 16f * density
        }
    ) {
        if (showBack) {
            // Counter-rotate so the back face isn't upside down.
            Box(Modifier.fillMaxSize().graphicsLayer { rotationX = 180f }) { back() }
        } else {
            front()
        }
    }
}
