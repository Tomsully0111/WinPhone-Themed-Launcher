package dev.metro.launcher.ui

import dev.metro.launcher.data.TileSpec

data class PlacedTile(val spec: TileSpec, val row: Int, val col: Int)

/**
 * First-fit packing on a fixed-width grid, like the Windows Phone start screen:
 * each tile takes the earliest free spot (top to bottom, left to right) where it fits.
 */
fun packTiles(tiles: List<TileSpec>, columns: Int = 4): List<PlacedTile> {
    val grid = mutableListOf<BooleanArray>()
    val result = ArrayList<PlacedTile>(tiles.size)

    fun fits(row: Int, col: Int, w: Int, h: Int): Boolean {
        for (r in row until row + h) {
            if (r >= grid.size) continue
            for (c in col until col + w) if (grid[r][c]) return false
        }
        return true
    }

    for (spec in tiles) {
        val w = spec.size.cols.coerceAtMost(columns)
        val h = spec.size.rows
        var placed: PlacedTile? = null
        var row = 0
        while (placed == null) {
            for (col in 0..columns - w) {
                if (fits(row, col, w, h)) {
                    while (grid.size < row + h) grid.add(BooleanArray(columns))
                    for (r in row until row + h) for (c in col until col + w) grid[r][c] = true
                    placed = PlacedTile(spec, row, col)
                    break
                }
            }
            row++
        }
        result.add(placed!!)
    }
    return result
}
