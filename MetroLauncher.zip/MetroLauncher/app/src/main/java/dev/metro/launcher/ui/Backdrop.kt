package dev.metro.launcher.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

/** How long each photo stays fully shown before the next one starts. */
const val SLIDESHOW_DWELL_MS = 20_000L

/** How long the tiles take, between them, to flip over to the next photo. */
const val SLIDESHOW_WINDOW_MS = 12_000L

/**
 * The start background, laid out to cover the whole start screen. Each tile draws just
 * the slice behind it, so the tiles look like windows onto one picture.
 *
 * For a slideshow, [base] is the photo every tile shows and [target] is the one they're
 * flipping to. Only those two are kept in memory.
 */
class BackdropState(val files: List<File>) {
    var origin by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(IntSize.Zero)
    var base by mutableIntStateOf(0)
    var target by mutableIntStateOf(0)

    private val images = mutableStateMapOf<Int, ImageBitmap>()

    fun image(index: Int): ImageBitmap? = images[index]

    suspend fun ensureLoaded(index: Int) {
        if (index !in files.indices || images.containsKey(index)) return
        val bitmap = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(files[index].absolutePath)?.asImageBitmap()
        } ?: return
        images[index] = bitmap
    }

    fun keepOnly(index: Int) {
        images.keys.filter { it != index }.forEach { images.remove(it) }
    }
}

val LocalBackdrop = compositionLocalOf<BackdropState?> { null }

/**
 * Where a tile sits on screen, measured before any flip, tilt or fly-in transform, and
 * which slideshow photo it's showing (-1 means the backdrop's [BackdropState.base]).
 * Every face of a tile uses this, so front and back show the same slice of the same photo.
 */
class TileOrigin {
    var position by mutableStateOf(Offset.Zero)
    var imageIndex by mutableIntStateOf(-1)
}

val LocalTileOrigin = staticCompositionLocalOf<TileOrigin?> { null }

/** A tile's background: its slice of the start background, or the accent color. */
@Composable
fun Modifier.tileSurface(): Modifier {
    val accent = LocalAccent.current
    val backdrop = LocalBackdrop.current ?: return this.background(accent)
    val tileOrigin = LocalTileOrigin.current
    var ownPosition by remember { mutableStateOf(Offset.Zero) }

    return this
        .then(
            // Outside a tile frame, fall back to measuring this element itself.
            if (tileOrigin == null) Modifier.onGloballyPositioned { ownPosition = it.positionInRoot() }
            else Modifier
        )
        .drawBehind {
            val position = tileOrigin?.position ?: ownPosition
            val index = tileOrigin?.imageIndex?.takeIf { it >= 0 } ?: backdrop.base
            val image = backdrop.image(index) ?: backdrop.image(backdrop.base)
            val area = backdrop.size
            if (image == null || area.width == 0 || area.height == 0) {
                drawRect(accent)
                return@drawBehind
            }
            val scale = max(area.width / image.width.toFloat(), area.height / image.height.toFloat())
            val w = (image.width * scale).roundToInt()
            val h = (image.height * scale).roundToInt()
            val left = backdrop.origin.x + (area.width - w) / 2f
            val top = backdrop.origin.y + (area.height - h) / 2f
            clipRect {
                drawImage(
                    image = image,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(image.width, image.height),
                    dstOffset = IntOffset((left - position.x).roundToInt(), (top - position.y).roundToInt()),
                    dstSize = IntSize(w, h),
                )
            }
            // A light shade keeps white tile text readable on bright photos.
            drawRect(Color.Black.copy(alpha = 0.18f))
        }
}
