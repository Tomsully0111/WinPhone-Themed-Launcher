package dev.metro.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * The start background photo, laid out to cover the whole start screen.
 * Each tile draws just the slice of it that sits behind the tile, so the tiles
 * look like windows onto one picture while the gaps between them stay solid.
 */
class BackdropState(val image: ImageBitmap) {
    var origin by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(IntSize.Zero)
}

val LocalBackdrop = compositionLocalOf<BackdropState?> { null }

/** A tile's background: its slice of the start background, or the accent color. */
@Composable
fun Modifier.tileSurface(): Modifier {
    val accent = LocalAccent.current
    val backdrop = LocalBackdrop.current ?: return this.background(accent)
    var position by remember { mutableStateOf(Offset.Zero) }

    return this
        .onGloballyPositioned { position = it.positionInRoot() }
        .drawBehind {
            val area = backdrop.size
            val image = backdrop.image
            if (area.width == 0 || area.height == 0) {
                drawRect(accent)
                return@drawBehind
            }
            val scale = max(area.width / image.width.toFloat(), area.height / image.height.toFloat())
            val w = (image.width * scale).roundToInt()
            val h = (image.height * scale).roundToInt()
            val left = backdrop.origin.x + (area.width - w) / 2f
            val top = backdrop.origin.y + (area.height - h) / 2f
            clipRect {
                drawImage(
                    image = image,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(image.width, image.height),
                    dstOffset = IntOffset((left - position.x).roundToInt(), (top - position.y).roundToInt()),
                    dstSize = IntSize(w, h),
                )
            }
            // A light shade keeps white tile text readable on bright photos.
            drawRect(Color.Black.copy(alpha = 0.18f))
        }
}
