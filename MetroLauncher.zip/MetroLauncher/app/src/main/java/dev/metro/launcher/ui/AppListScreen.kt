package dev.metro.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.metro.launcher.data.AppEntry
import kotlinx.coroutines.launch

private val SECTIONS = listOf("#") + ('a'..'z').map { it.toString() }

private fun sectionFor(label: String): String {
    val c = label.trim().firstOrNull()?.lowercaseChar() ?: return "#"
    return if (c in 'a'..'z') c.toString() else "#"
}

@Composable
fun AppListScreen(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onPin: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
) {
    val groups = remember(apps) { apps.groupBy { sectionFor(it.label) } }
    val ordered = remember(groups) { SECTIONS.filter { groups.containsKey(it) } }
    val headerIndex = remember(ordered, groups) {
        val map = HashMap<String, Int>()
        var index = 0
        for (s in ordered) {
            map[s] = index
            index += 1 + groups.getValue(s).size
        }
        map
    }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var showJumpGrid by remember { mutableStateOf(false) }

    BackHandler(enabled = showJumpGrid) { showJumpGrid = false }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 24.dp),
        ) {
            for (section in ordered) {
                item(key = "header:$section") {
                    LetterHeader(section) { showJumpGrid = true }
                }
                items(groups.getValue(section), key = { it.key }) { app ->
                    AppRow(app, onLaunch, onPin, onAppInfo, onUninstall)
                }
            }
        }

        if (showJumpGrid) {
            JumpGrid(
                available = ordered.toSet(),
                onPick = { section ->
                    showJumpGrid = false
                    headerIndex[section]?.let { scope.launch { listState.scrollToItem(it) } }
                },
                onDismiss = { showJumpGrid = false },
            )
        }
    }
}

@Composable
private fun LetterHeader(letter: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier
            .padding(vertical = 6.dp)
            .size(48.dp)
            .border(2.dp, accent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.BottomStart,
    ) {
        Text(
            letter,
            color = accent,
            fontSize = 26.sp,
            fontFamily = MetroFont,
            modifier = Modifier.padding(start = 6.dp, bottom = 2.dp),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppRow(
    app: AppEntry,
    onLaunch: (AppEntry) -> Unit,
    onPin: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
) {
    val accent = LocalAccent.current
    var menuOpen by remember { mutableStateOf(false) }

    Box {
        Row(
            Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { menuOpen = true })
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(48.dp).background(accent), contentAlignment = Alignment.Center) {
                Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text(
                app.label,
                color = Color.White,
                fontSize = 20.sp,
                fontFamily = MetroFont,
                fontWeight = FontWeight.Light,
                maxLines = 1,
            )
        }

        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(text = { Text("pin to start") }, onClick = { menuOpen = false; onPin(app) })
            DropdownMenuItem(text = { Text("app info") }, onClick = { menuOpen = false; onAppInfo(app) })
            DropdownMenuItem(text = { Text("uninstall") }, onClick = { menuOpen = false; onUninstall(app) })
        }
    }
}

/** The letter grid that appears when you tap a section header. */
@Composable
private fun JumpGrid(available: Set<String>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.92f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ),
        contentAlignment = Alignment.Center,
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(SECTIONS.size) { i ->
                val section = SECTIONS[i]
                val enabled = section in available
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .background(if (enabled) accent else Color(0xFF2A2A2A))
                        .then(if (enabled) Modifier.clickable { onPick(section) } else Modifier),
                    contentAlignment = Alignment.BottomStart,
                ) {
                    Text(
                        section,
                        color = if (enabled) Color.White else Color.Gray,
                        fontSize = 28.sp,
                        fontFamily = MetroFont,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.padding(6.dp),
                    )
                }
            }
        }
    }
}
