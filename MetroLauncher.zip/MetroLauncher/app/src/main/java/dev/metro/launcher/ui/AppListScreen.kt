package dev.metro.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.metro.launcher.data.AppEntry
import kotlinx.coroutines.launch
import java.text.Normalizer

private val SECTIONS = listOf("#") + ('a'..'z').map { it.toString() }
private val DIACRITICS = Regex("\\p{M}+")

private fun sectionFor(label: String): String {
    val c = label.trim().firstOrNull()?.lowercaseChar() ?: return "#"
    return if (c in 'a'..'z') c.toString() else "#"
}

/** Lowercase with accents removed, so "cafe" finds "Café". */
private fun normalize(text: String): String =
    Normalizer.normalize(text, Normalizer.Form.NFD).replace(DIACRITICS, "").lowercase()

/**
 * Matches anywhere in an app's name, best matches first:
 * names that start with the query, then a word that starts with it, then anything containing it.
 */
private fun searchApps(apps: List<AppEntry>, query: String): List<AppEntry> {
    val q = normalize(query.trim())
    if (q.isEmpty()) return emptyList()
    return apps.mapNotNull { app ->
        val label = normalize(app.label)
        val rank = when {
            label.startsWith(q) -> 0
            label.split(' ', '-', '_', '.', '&').any { it.startsWith(q) } -> 1
            label.contains(q) -> 2
            else -> return@mapNotNull null
        }
        rank to app
    }
        .sortedWith(compareBy({ it.first }, { it.second.label.lowercase() }))
        .map { it.second }
}

@Composable
fun AppListScreen(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onPin: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
    onWebSearch: (String) -> Unit,
    isNew: (AppEntry) -> Boolean,
) {
    val colors = LocalMetroColors.current
    val groups = remember(apps) { apps.groupBy { sectionFor(it.label) } }
    val ordered = remember(groups) { SECTIONS.filter { groups.containsKey(it) } }
    val headerIndex = remember(ordered, groups) {
        val map = HashMap<String, Int>()
        var index = 0
        for (s in ordered) {
            map[s] = index
            index += 1 + groups.getValue(s).size
        }
        map
    }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    var showJumpGrid by remember { mutableStateOf(false) }

    var query by remember { mutableStateOf("") }
    val searching = query.isNotBlank()
    val results = remember(apps, query) { searchApps(apps, query) }

    fun resetSearch() {
        query = ""
        focusManager.clearFocus()
    }

    val launchFromSearch: (AppEntry) -> Unit = { app ->
        resetSearch()
        onLaunch(app)
    }

    BackHandler(enabled = searching) { resetSearch() }
    BackHandler(enabled = showJumpGrid) { showJumpGrid = false }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        SearchField(
            query = query,
            onQueryChange = { query = it },
            // The keyboard's search key opens the top match, or searches the web if nothing matches.
            onSearch = {
                val top = results.firstOrNull()
                when {
                    top != null -> launchFromSearch(top)
                    searching -> {
                        val q = query.trim()
                        resetSearch()
                        onWebSearch(q)
                    }
                }
            },
            onClear = { query = "" },
        )

        Box(Modifier.fillMaxWidth().weight(1f)) {
            if (searching) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    if (results.isEmpty()) {
                        item(key = "empty") {
                            Text(
                                "No apps match \u201c${query.trim()}\u201d.",
                                color = colors.subtle,
                                fontSize = 16.sp,
                                fontFamily = MetroFont,
                                modifier = Modifier.padding(vertical = 12.dp),
                            )
                        }
                    }
                    items(results, key = { it.key }) { app ->
                        AppRow(app, isNew(app), launchFromSearch, onPin, onAppInfo, onUninstall)
                    }
                    item(key = "web") {
                        WebSearchRow(query.trim()) {
                            val q = query.trim()
                            resetSearch()
                            onWebSearch(q)
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    for (section in ordered) {
                        item(key = "header:$section") {
                            LetterHeader(section) { showJumpGrid = true }
                        }
                        items(groups.getValue(section), key = { it.key }) { app ->
                            AppRow(app, isNew(app), onLaunch, onPin, onAppInfo, onUninstall)
                        }
                    }
                }
            }

            if (showJumpGrid && !searching) {
                JumpGrid(
                    available = ordered.toSet(),
                    onPick = { section ->
                        showJumpGrid = false
                        headerIndex[section]?.let { scope.launch { listState.scrollToItem(it) } }
                    },
                    onDismiss = { showJumpGrid = false },
                )
            }
        }
    }
}

/** A Metro-style text box: dark when idle, white while you type. */
@Composable
private fun SearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
) {
    val accent = LocalAccent.current
    val colors = LocalMetroColors.current
    var focused by remember { mutableStateOf(false) }
    val active = focused || query.isNotEmpty()

    BasicTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.Black, fontSize = 18.sp, fontFamily = MetroFont),
        cursorBrush = SolidColor(accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
            .onFocusChanged { focused = it.isFocused },
        decorationBox = { innerTextField ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(if (active) Color.White else colors.field)
                    .then(if (active) Modifier.border(2.dp, accent) else Modifier)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            "search apps",
                            color = if (active) Color.Gray else colors.fieldHint,
                            fontSize = 18.sp,
                            fontFamily = MetroFont,
                        )
                    }
                    innerTextField()
                }
                if (query.isNotEmpty()) {
                    Text(
                        "✕",
                        color = Color.Black,
                        fontSize = 16.sp,
                        modifier = Modifier
                            .clickable(onClick = onClear)
                            .padding(start = 12.dp),
                    )
                }
            }
        },
    )
}

@Composable
private fun WebSearchRow(query: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Text(
        "search the web for \u201c$query\u201d",
        color = accent,
        fontSize = 18.sp,
        fontFamily = MetroFont,
        maxLines = 2,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
    )
}

@Composable
private fun LetterHeader(letter: String, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Box(
        Modifier
            .padding(vertical = 6.dp)
            .size(48.dp)
            .border(2.dp, accent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.BottomStart,
    ) {
        Text(
            letter,
            color = accent,
            fontSize = 26.sp,
            fontFamily = MetroFont,
            modifier = Modifier.padding(start = 6.dp, bottom = 2.dp),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppRow(
    app: AppEntry,
    isNew: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onPin: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
    onUninstall: (AppEntry) -> Unit,
) {
    val accent = LocalAccent.current
    val colors = LocalMetroColors.current
    var menuOpen by remember { mutableStateOf(false) }

    Box {
        Row(
            Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { menuOpen = true })
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(48.dp).background(accent), contentAlignment = Alignment.Center) {
                Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    app.label,
                    color = colors.foreground,
                    fontSize = 20.sp,
                    fontFamily = MetroFont,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                )
                // Recently installed and not opened yet, as on Windows Phone 8.1.
                if (isNew) {
                    Text("new", color = accent, fontSize = 13.sp, fontFamily = MetroFont)
                }
            }
        }

        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(text = { Text("pin to start") }, onClick = { menuOpen = false; onPin(app) })
            DropdownMenuItem(text = { Text("app info") }, onClick = { menuOpen = false; onAppInfo(app) })
            DropdownMenuItem(text = { Text("uninstall") }, onClick = { menuOpen = false; onUninstall(app) })
        }
    }
}

/** The letter grid that appears when you tap a section header. */
@Composable
private fun JumpGrid(available: Set<String>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val accent = LocalAccent.current
    val colors = LocalMetroColors.current
    Box(
        Modifier
            .fillMaxSize()
            .background(colors.background.copy(alpha = 0.92f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            ),
        contentAlignment = Alignment.Center,
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(SECTIONS.size) { i ->
                val section = SECTIONS[i]
                val enabled = section in available
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .background(if (enabled) accent else colors.field)
                        .then(if (enabled) Modifier.clickable { onPick(section) } else Modifier),
                    contentAlignment = Alignment.BottomStart,
                ) {
                    Text(
                        section,
                        color = if (enabled) Color.White else colors.subtle,
                        fontSize = 28.sp,
                        fontFamily = MetroFont,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.padding(6.dp),
                    )
                }
            }
        }
    }
}
