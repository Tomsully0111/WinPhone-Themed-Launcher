package dev.metro.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.metro.launcher.data.AppEntry
import dev.metro.launcher.notifications.AppNotifications

/** An open folder. Tap outside or press Back to close it. */
@Composable
fun FolderOverlay(
    apps: List<AppEntry>,
    notifications: Map<String, AppNotifications>,
    onLaunch: (AppEntry) -> Unit,
    onRemove: (AppEntry) -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = LocalMetroColors.current
    BackHandler(onBack = onDismiss)

    Box(
        Modifier
            .fillMaxSize()
            .background(colors.background.copy(alpha = 0.94f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss,
            )
            .systemBarsPadding()
            .padding(16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(
                "folder",
                color = colors.foreground,
                fontSize = 30.sp,
                fontFamily = MetroFont,
                fontWeight = FontWeight.Light,
            )
            Spacer(Modifier.height(12.dp))
            apps.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { app ->
                        FolderItem(
                            app = app,
                            count = notifications[app.component.packageName]?.count ?: 0,
                            onLaunch = onLaunch,
                            onRemove = onRemove,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(12.dp))
            }
            Text(
                "Long-press an app to take it out of the folder.",
                color = colors.subtle,
                fontSize = 13.sp,
                fontFamily = MetroFont,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderItem(
    app: AppEntry,
    count: Int,
    onLaunch: (AppEntry) -> Unit,
    onRemove: (AppEntry) -> Unit,
    modifier: Modifier,
) {
    val colors = LocalMetroColors.current
    val accent = LocalAccent.current
    var menuOpen by remember { mutableStateOf(false) }

    Column(modifier) {
        Box {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(accent)
                    .combinedClickable(onClick = { onLaunch(app) }, onLongClick = { menuOpen = true }),
                contentAlignment = Alignment.Center,
            ) {
                Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.fillMaxSize(0.55f))
                if (count > 0) {
                    Text(
                        countLabel(count),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontFamily = MetroFont,
                        modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                    )
                }
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("remove from folder") },
                    onClick = {
                        menuOpen = false
                        onRemove(app)
                    },
                )
            }
        }
        Text(
            app.label,
            color = colors.foreground,
            fontSize = 12.sp,
            fontFamily = MetroFont,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
