package dev.metro.launcher.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What a tile needs to know about one app's notifications. Held in memory only, never saved. */
data class AppNotifications(val count: Int, val title: String?, val text: String?)

/** Shares the latest notification summary between the listener service and the start screen. */
object NotificationHub {
    private val _byPackage = MutableStateFlow<Map<String, AppNotifications>>(emptyMap())
    val byPackage: StateFlow<Map<String, AppNotifications>> = _byPackage.asStateFlow()

    fun publish(notifications: List<StatusBarNotification>) {
        _byPackage.value = notifications
            .groupBy { it.packageName }
            .mapValues { (_, items) ->
                val latest = items.maxBy { it.postTime }
                val extras = latest.notification.extras
                AppNotifications(
                    count = items.size,
                    title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
                    text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
                )
            }
    }

    fun clear() {
        _byPackage.value = emptyMap()
    }
}

class TileNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() = publish()

    override fun onListenerDisconnected() = NotificationHub.clear()

    override fun onNotificationPosted(sbn: StatusBarNotification?) = publish()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) = publish()

    private fun publish() {
        val active = runCatching { activeNotifications }.getOrNull() ?: return
        NotificationHub.publish(
            active.filter {
                // Count things you'd want to read, not music players, downloads or group headers.
                it.isClearable && !it.isOngoing &&
                    (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
            }
        )
    }
}
