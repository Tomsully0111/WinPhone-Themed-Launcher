package dev.metro.launcher.ui

import android.graphics.BitmapFactory
import android.text.format.DateFormat
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.metro.launcher.data.AppEntry
import dev.metro.launcher.data.NextEvent
import dev.metro.launcher.data.Person
import dev.metro.launcher.data.TileSize
import dev.metro.launcher.media.MediaHub
import dev.metro.launcher.media.NowPlaying
import dev.metro.launcher.notifications.AppNotifications
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.random.Random

/** Everything the live tiles can show beyond the app itself. */
data class LiveData(
    val notifications: Map<String, AppNotifications>,
    val showPreviews: Boolean,
    val notificationAccess: Boolean,
    val nextEvent: NextEvent?,
    val calendarAccess: Boolean,
    val nowPlaying: NowPlaying?,
    val photos: List<File>,
    val people: List<Person>,
    val contactsAccess: Boolean,
)

internal fun countLabel(count: Int) = if (count > 99) "99+" else count.toString()

/** Keeps white text readable over photos. */
private val OverPhoto = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.7f), Offset(0f, 1f), 6f))

// ---------------------------------------------------------------- Apps

/**
 * Front: icon and name, with a count beside the icon when there are notifications.
 * Back: the latest notification (or just how many), or the app's name set large when there's nothing new.
 */
@Composable
fun AppTile(
    app: AppEntry,
    size: TileSize,
    unit: Dp,
    live: Boolean,
    seed: Int,
    news: AppNotifications?,
    showPreviews: Boolean,
) {
    val count = news?.count ?: 0
    val hasNews = count > 0
    val small = size == TileSize.SMALL
    val wide = size == TileSize.WIDE

    FlipFaces(
        // Small tiles stayed still on Windows Phone too; they show a count instead.
        live = live && !small,
        seed = seed,
        // Tiles with something new flip more often.
        frontDwellMs = if (hasNews) 5_000L..9_000L else 8_000L..16_000L,
        backDwellMs = if (hasNews) 4_000L..6_000L else 3_000L..5_000L,
        modifier = Modifier.fillMaxSize(),
        front = {
            Box(Modifier.fillMaxSize().tileSurface()) {
                if (hasNews && !small) {
                    Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
                        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(unit * 0.5f))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            countLabel(count),
                            color = Color.White,
                            fontSize = 32.sp,
                            fontFamily = MetroFont,
                            fontWeight = FontWeight.Light,
                        )
                    }
                } else {
                    Image(
                        bitmap = app.icon,
                        contentDescription = app.label,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(if (small) unit * 0.5f else unit * 0.6f),
                    )
                }
                if (hasNews && small) {
                    Text(
                        countLabel(count),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontFamily = MetroFont,
                        modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                    )
                }
                if (!small) {
                    Text(
                        app.label,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontFamily = MetroFont,
                        maxLines = 1,
                        modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
                    )
                }
            }
        },
        back = {
            Box(Modifier.fillMaxSize().tileSurface().padding(10.dp)) {
                if (news != null && hasNews) {
                    Column(Modifier.align(Alignment.TopStart)) {
                        if (showPreviews && (news.title != null || news.text != null)) {
                            news.title?.let {
                                Text(
                                    it,
                                    color = Color.White,
                                    fontSize = if (wide) 20.sp else 17.sp,
                                    fontFamily = MetroFont,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            news.text?.let {
                                Text(
                                    it,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    lineHeight = 17.sp,
                                    fontFamily = MetroFont,
                                    maxLines = if (wide) 2 else 4,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        } else {
                            Text(
                                if (count == 1) "1 new notification" else "$count new notifications",
                                color = Color.White,
                                fontSize = if (wide) 26.sp else 20.sp,
                                lineHeight = if (wide) 28.sp else 23.sp,
                                fontFamily = MetroFont,
                                fontWeight = FontWeight.Light,
                                maxLines = 3,
                            )
                        }
                    }
                    Text(
                        app.label,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontFamily = MetroFont,
                        maxLines = 1,
                        modifier = Modifier.align(Alignment.BottomStart),
                    )
                } else {
                    Text(
                        app.label.lowercase(),
                        color = Color.White,
                        fontSize = if (wide) 30.sp else 22.sp,
                        lineHeight = if (wide) 32.sp else 24.sp,
                        fontFamily = MetroFont,
                        fontWeight = FontWeight.Light,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.align(Alignment.TopStart),
                    )
                    Image(
                        bitmap = app.icon,
                        contentDescription = null,
                        modifier = Modifier.align(Alignment.BottomEnd).size(unit * 0.3f),
                    )
                }
            }
        },
    )
}

// ---------------------------------------------------------------- Folders

/** Shows small icons of the apps inside, like Windows Phone 8.1 live folders. */
@Composable
fun FolderTile(size: TileSize, apps: List<AppEntry>, unread: Int, unit: Dp) {
    val small = size == TileSize.SMALL
    val perRow = if (size == TileSize.WIDE) 4 else 2
    val maxIcons = if (size == TileSize.WIDE) 8 else 4
    val iconSize = if (small) unit * 0.3f else unit * 0.42f

    Box(Modifier.fillMaxSize().tileSurface()) {
        Column(
            Modifier.align(Alignment.Center),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            apps.take(maxIcons).chunked(perRow).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { app ->
                        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(iconSize))
                    }
                }
            }
        }
        if (!small) {
            Text(
                "folder",
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = MetroFont,
                modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
            )
        }
        if (unread > 0) {
            Text(
                countLabel(unread),
                color = Color.White,
                fontSize = if (small) 12.sp else 16.sp,
                fontFamily = MetroFont,
                modifier = Modifier.align(Alignment.TopEnd).padding(if (small) 3.dp else 8.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- Clock and calendar

/** The current time, updated on the minute. */
@Composable
private fun rememberNow(): LocalDateTime {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L)
        }
    }
    return now
}

/** Front: the time. Back: the day and date. */
@Composable
fun ClockTile(size: TileSize, live: Boolean, seed: Int) {
    val context = LocalContext.current
    val now = rememberNow()
    val timePattern = if (DateFormat.is24HourFormat(context)) "H:mm" else "h:mm"
    val small = size == TileSize.SMALL

    FlipFaces(
        live = live,
        seed = seed,
        frontDwellMs = 6_000L..10_000L,
        backDwellMs = 4_000L..6_000L,
        modifier = Modifier.fillMaxSize(),
        front = {
            Column(
                Modifier.fillMaxSize().tileSurface().padding(10.dp),
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    now.format(DateTimeFormatter.ofPattern(timePattern)),
                    color = Color.White,
                    fontFamily = MetroFont,
                    fontWeight = FontWeight.Light,
                    fontSize = if (small) 20.sp else 44.sp,
                )
                if (!small) {
                    Text(
                        now.format(DateTimeFormatter.ofPattern("MMMM d")).lowercase(),
                        color = Color.White,
                        fontFamily = MetroFont,
                        fontSize = 14.sp,
                    )
                }
            }
        },
        back = { DayFace(now, size) },
    )
}

/** The big day-of-month face used on the back of the clock and calendar tiles. */
@Composable
private fun DayFace(now: LocalDateTime, size: TileSize) {
    val small = size == TileSize.SMALL
    Column(
        Modifier.fillMaxSize().tileSurface().padding(10.dp),
        verticalArrangement = Arrangement.Bottom,
    ) {
        if (small) {
            Text(
                now.dayOfMonth.toString(),
                color = Color.White,
                fontFamily = MetroFont,
                fontWeight = FontWeight.Light,
                fontSize = 28.sp,
            )
            Text(
                now.format(DateTimeFormatter.ofPattern("EEE")).lowercase(),
                color = Color.White,
                fontFamily = MetroFont,
                fontSize = 12.sp,
            )
        } else {
            Text(
                now.format(DateTimeFormatter.ofPattern("EEEE")).lowercase(),
                color = Color.White,
                fontFamily = MetroFont,
                fontWeight = FontWeight.Light,
                fontSize = if (size == TileSize.WIDE) 36.sp else 28.sp,
            )
            Text(
                now.format(DateTimeFormatter.ofPattern("MMMM d, yyyy")).lowercase(),
                color = Color.White,
                fontFamily = MetroFont,
                fontSize = 14.sp,
            )
        }
    }
}

private fun describeWhen(event: NextEvent, now: LocalDateTime, is24Hour: Boolean): String {
    // All-day events are stored at UTC midnight; timed ones in real time.
    val start = Instant.ofEpochMilli(event.begin)
        .atZone(if (event.allDay) ZoneOffset.UTC else ZoneId.systemDefault())
        .toLocalDateTime()
    val day = when (start.toLocalDate()) {
        now.toLocalDate() -> "today"
        now.toLocalDate().plusDays(1) -> "tomorrow"
        else -> start.format(DateTimeFormatter.ofPattern("EEEE")).lowercase()
    }
    if (event.allDay) return "$day, all day"
    if (!start.isAfter(now)) return "now"
    val time = start.format(DateTimeFormatter.ofPattern(if (is24Hour) "H:mm" else "h:mm a")).lowercase()
    return "$day $time"
}

/** Front: your next event. Back: the day and date. */
@Composable
fun CalendarTile(size: TileSize, live: Boolean, seed: Int, event: NextEvent?, hasAccess: Boolean) {
    val context = LocalContext.current
    val now = rememberNow()
    val is24Hour = DateFormat.is24HourFormat(context)
    val small = size == TileSize.SMALL
    val wide = size == TileSize.WIDE

    FlipFaces(
        live = live && !small && hasAccess,
        seed = seed,
        frontDwellMs = 7_000L..12_000L,
        backDwellMs = 4_000L..6_000L,
        modifier = Modifier.fillMaxSize(),
        front = {
            if (small) {
                DayFace(now, size)
            } else {
                Column(Modifier.fillMaxSize().tileSurface().padding(10.dp)) {
                    when {
                        !hasAccess -> {
                            Text("calendar", color = Color.White, fontSize = 22.sp, fontFamily = MetroFont, fontWeight = FontWeight.Light)
                            Spacer(Modifier.weight(1f))
                            Text("Allow calendar access in settings to see your next event.", color = Color.White, fontSize = 13.sp, fontFamily = MetroFont)
                        }
                        event == null -> {
                            Text("no events", color = Color.White, fontSize = 22.sp, fontFamily = MetroFont, fontWeight = FontWeight.Light)
                            Text("in the next week", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, fontFamily = MetroFont)
                            Spacer(Modifier.weight(1f))
                            CalendarFooter(now)
                        }
                        else -> {
                            Text(
                                event.title,
                                color = Color.White,
                                fontSize = if (wide) 22.sp else 18.sp,
                                lineHeight = if (wide) 25.sp else 21.sp,
                                fontFamily = MetroFont,
                                fontWeight = FontWeight.Light,
                                maxLines = if (wide) 2 else 3,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(describeWhen(event, now, is24Hour), color = Color.White, fontSize = 14.sp, fontFamily = MetroFont)
                            event.location?.let {
                                Text(
                                    it,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 13.sp,
                                    fontFamily = MetroFont,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Spacer(Modifier.weight(1f))
                            CalendarFooter(now)
                        }
                    }
                }
            }
        },
        back = { DayFace(now, size) },
    )
}

@Composable
private fun CalendarFooter(now: LocalDateTime) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        Text("calendar", color = Color.White, fontSize = 13.sp, fontFamily = MetroFont)
        Spacer(Modifier.weight(1f))
        Text(
            now.dayOfMonth.toString(),
            color = Color.White,
            fontSize = 22.sp,
            fontFamily = MetroFont,
            fontWeight = FontWeight.Light,
        )
    }
}

// ---------------------------------------------------------------- Music

enum class MediaGlyph { PLAY, PAUSE, NEXT, PREVIOUS }

/** Drawn rather than typed, so it never turns into an emoji. */
@Composable
private fun MediaButton(glyph: MediaGlyph, onClick: () -> Unit, buttonSize: Dp = 32.dp) {
    Box(
        Modifier
            .size(buttonSize)
            .border(1.5.dp, Color.White, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(buttonSize * 0.4f)) {
            val w = size.width
            val h = size.height
            fun triangle(fromX: Float, toX: Float) = Path().apply {
                moveTo(fromX, 0f)
                lineTo(toX, h / 2f)
                lineTo(fromX, h)
                close()
            }
            when (glyph) {
                MediaGlyph.PLAY -> drawPath(triangle(w * 0.15f, w), Color.White)
                MediaGlyph.PAUSE -> {
                    drawRect(Color.White, topLeft = Offset(w * 0.1f, 0f), size = Size(w * 0.28f, h))
                    drawRect(Color.White, topLeft = Offset(w * 0.62f, 0f), size = Size(w * 0.28f, h))
                }
                MediaGlyph.NEXT -> {
                    drawPath(triangle(0f, w * 0.75f), Color.White)
                    drawRect(Color.White, topLeft = Offset(w * 0.8f, 0f), size = Size(w * 0.2f, h))
                }
                MediaGlyph.PREVIOUS -> {
                    drawPath(triangle(w, w * 0.25f), Color.White)
                    drawRect(Color.White, topLeft = Offset(0f, 0f), size = Size(w * 0.2f, h))
                }
            }
        }
    }
}

@Composable
private fun ArtOrNote(art: ImageBitmap?) {
    if (art != null) {
        Image(art, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("♪", color = Color.White, fontSize = 36.sp)
        }
    }
}

/** What's playing in any music or podcast app, with controls. */
@Composable
fun MusicTile(size: TileSize, now: NowPlaying?, hasAccess: Boolean) {
    val small = size == TileSize.SMALL
    val wide = size == TileSize.WIDE

    Box(Modifier.fillMaxSize().tileSurface()) {
        when {
            !hasAccess || now == null -> {
                Text("♪", color = Color.White, fontSize = 40.sp, modifier = Modifier.align(Alignment.Center))
                if (!small) {
                    Text(
                        if (!hasAccess) "Turn on notifications on tiles in settings." else "nothing playing",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontFamily = MetroFont,
                        maxLines = 2,
                        modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
                    )
                }
            }
            wide -> Row(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxHeight().aspectRatio(1f)) { ArtOrNote(now.art) }
                Column(Modifier.weight(1f).fillMaxHeight().padding(10.dp)) {
                    Text(
                        now.title ?: "unknown",
                        color = Color.White,
                        fontSize = 20.sp,
                        lineHeight = 23.sp,
                        fontFamily = MetroFont,
                        fontWeight = FontWeight.Light,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    now.artist?.let {
                        Text(
                            it,
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 14.sp,
                            fontFamily = MetroFont,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MediaButton(MediaGlyph.PREVIOUS, MediaHub::previous)
                        MediaButton(if (now.playing) MediaGlyph.PAUSE else MediaGlyph.PLAY, MediaHub::playPause)
                        MediaButton(MediaGlyph.NEXT, MediaHub::next)
                    }
                }
            }
            else -> {
                ArtOrNote(now.art)
                if (!small) {
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                now.title ?: "unknown",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontFamily = MetroFont,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            now.artist?.let {
                                Text(
                                    it,
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    fontFamily = MetroFont,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                    Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                        MediaButton(if (now.playing) MediaGlyph.PAUSE else MediaGlyph.PLAY, MediaHub::playPause)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Photos

/** Cycles through the photos you picked, with a slow crossfade. */
@Composable
fun PhotosTile(size: TileSize, photos: List<File>, live: Boolean, seed: Int) {
    var index by remember(photos) { mutableIntStateOf(0) }
    var image by remember(photos) { mutableStateOf<ImageBitmap?>(null) }

    // Load one photo at a time, so a big set never sits in memory.
    LaunchedEffect(photos, index) {
        val file = photos.getOrNull(index)
        image = file?.let { f ->
            withContext(Dispatchers.IO) { BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() }
        }
    }
    LaunchedEffect(photos, live) {
        if (!live || photos.size < 2) return@LaunchedEffect
        val random = Random(seed)
        while (true) {
            delay(random.nextLong(6_000L, 10_000L))
            index = (index + 1) % photos.size
        }
    }

    Box(Modifier.fillMaxSize().tileSurface()) {
        Crossfade(targetState = image, animationSpec = tween(800), label = "photos") { picture ->
            if (picture != null) {
                Image(picture, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        if (photos.isEmpty()) {
            Text(
                "Choose photos in settings.",
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = MetroFont,
                modifier = Modifier.align(Alignment.Center).padding(8.dp),
            )
        }
        if (size != TileSize.SMALL) {
            Text(
                "photos",
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = MetroFont,
                style = OverPhoto,
                modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- People

/** A mosaic of faces where one at a time flips over to someone new. */
@Composable
fun PeopleTile(size: TileSize, people: List<Person>, hasAccess: Boolean, live: Boolean, seed: Int) {
    val (cols, rows) = when (size) {
        TileSize.SMALL -> 2 to 2
        TileSize.MEDIUM -> 3 to 3
        TileSize.WIDE -> 6 to 3
    }

    if (!hasAccess || people.isEmpty()) {
        Box(Modifier.fillMaxSize().tileSurface().padding(8.dp)) {
            Text(
                "people",
                color = Color.White,
                fontSize = if (size == TileSize.SMALL) 13.sp else 22.sp,
                fontFamily = MetroFont,
                fontWeight = FontWeight.Light,
            )
            if (size != TileSize.SMALL) {
                Text(
                    if (!hasAccess) "Allow contacts access in settings." else "No contacts yet.",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontFamily = MetroFont,
                    modifier = Modifier.align(Alignment.BottomStart),
                )
            }
        }
        return
    }

    val cellCount = cols * rows
    val shown = remember(people, cellCount) {
        mutableStateListOf<Int>().apply { repeat(cellCount) { add(it % people.size) } }
    }
    LaunchedEffect(people, cellCount, live) {
        if (!live || people.size < 2) return@LaunchedEffect
        val random = Random(seed)
        while (true) {
            delay(random.nextLong(2_000L, 4_000L))
            val cell = random.nextInt(cellCount)
            val offScreen = people.indices.filter { it !in shown }
            shown[cell] = if (offScreen.isNotEmpty()) offScreen.random(random) else random.nextInt(people.size)
        }
    }

    Column(Modifier.fillMaxSize().tileSurface()) {
        for (r in 0 until rows) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                for (c in 0 until cols) {
                    val i = r * cols + c
                    key(i) {
                        PeopleCell(people[shown[i]], Modifier.weight(1f).fillMaxHeight())
                    }
                }
            }
        }
    }
}

@Composable
private fun PeopleCell(person: Person, modifier: Modifier) {
    val flip = remember { Animatable(0f) }
    LaunchedEffect(person.id) {
        flip.snapTo(90f)
        flip.animateTo(0f, tween(450))
    }
    Box(
        modifier.graphicsLayer {
            rotationX = flip.value
            cameraDistance = 12f * density
        },
        contentAlignment = Alignment.Center,
    ) {
        if (person.photo != null) {
            Image(person.photo, contentDescription = person.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                Text(person.initials, color = Color.White, fontSize = 14.sp, fontFamily = MetroFont)
            }
        }
    }
}
