package dev.metro.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import dev.metro.launcher.data.CALENDAR_TILE_KEY
import dev.metro.launcher.data.CLOCK_TILE_KEY
import dev.metro.launcher.data.MUSIC_TILE_KEY
import dev.metro.launcher.data.PEOPLE_TILE_KEY
import dev.metro.launcher.data.PHOTOS_TILE_KEY

/** What the settings screen shows. */
data class SettingsState(
    val accent: Int,
    val liveTiles: Boolean,
    val moreTiles: Boolean,
    val lightTheme: Boolean,
    val hasBackground: Boolean,
    val notificationAccess: Boolean,
    val showPreviews: Boolean,
    val pinned: Set<String>,
    val calendarDenied: Boolean,
    val contactsDenied: Boolean,
)

/** What the settings screen can do. */
class SettingsActions(
    val pickAccent: (Int) -> Unit,
    val setLiveTiles: (Boolean) -> Unit,
    val setMoreTiles: (Boolean) -> Unit,
    val setLightTheme: (Boolean) -> Unit,
    val chooseBackground: () -> Unit,
    val removeBackground: () -> Unit,
    val openNotificationAccess: () -> Unit,
    val setShowPreviews: (Boolean) -> Unit,
    val pinClock: () -> Unit,
    val pinCalendar: () -> Unit,
    val pinMusic: () -> Unit,
    val choosePhotos: () -> Unit,
    val pinPeople: () -> Unit,
    val openAppSettings: () -> Unit,
    val dismiss: () -> Unit,
)

@Composable
fun SettingsDialog(state: SettingsState, actions: SettingsActions) {
    val colors = LocalMetroColors.current
    Dialog(onDismissRequest = actions.dismiss) {
        Column(
            Modifier
                .background(colors.panel)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                "settings",
                color = colors.foreground,
                fontSize = 30.sp,
                fontFamily = MetroFont,
                fontWeight = FontWeight.Light,
            )

            SectionHeader("start")
            SettingSwitch(
                title = "live tiles",
                subtitle = if (state.liveTiles) "Tiles flip and animate." else "Tiles stay still.",
                checked = state.liveTiles,
                onChange = actions.setLiveTiles,
            )
            SettingSwitch(
                title = "show more tiles",
                subtitle = "Three medium tiles across instead of two.",
                checked = state.moreTiles,
                onChange = actions.setMoreTiles,
            )
            SettingSwitch(
                title = "light theme",
                subtitle = "White background with dark text.",
                checked = state.lightTheme,
                onChange = actions.setLightTheme,
            )
            SettingAction(
                title = "start background",
                subtitle = if (state.hasBackground) {
                    "Your photo shows through the tiles. Tap to choose another."
                } else {
                    "Choose a photo to show through your tiles."
                },
                onClick = actions.chooseBackground,
            )
            if (state.hasBackground) {
                SettingAction(
                    title = "remove start background",
                    subtitle = "Go back to solid accent-colored tiles.",
                    onClick = actions.removeBackground,
                )
            }

            SectionHeader("notifications")
            SettingAction(
                title = "notifications on tiles",
                subtitle = if (state.notificationAccess) {
                    "On. Tap to manage notification access in Android settings."
                } else {
                    "Off. Tap to allow notification access in Android settings."
                },
                onClick = actions.openNotificationAccess,
            )
            if (state.notificationAccess) {
                SettingSwitch(
                    title = "show previews",
                    subtitle = if (state.showPreviews) {
                        "Tiles show the sender and message."
                    } else {
                        "Tiles show only how many notifications."
                    },
                    checked = state.showPreviews,
                    onChange = actions.setShowPreviews,
                )
            }

            SectionHeader("tiles")
            if (CLOCK_TILE_KEY !in state.pinned) {
                SettingAction("pin clock tile", "The time, then the day and date.", actions.pinClock)
            }
            if (CALENDAR_TILE_KEY !in state.pinned) {
                SettingAction(
                    title = "pin calendar tile",
                    subtitle = if (state.calendarDenied) {
                        "Calendar access is off. Tap to turn it on in app settings."
                    } else {
                        "Shows your next event. Asks for calendar access."
                    },
                    onClick = if (state.calendarDenied) actions.openAppSettings else actions.pinCalendar,
                )
            }
            if (MUSIC_TILE_KEY !in state.pinned) {
                SettingAction(
                    title = "pin music tile",
                    subtitle = if (state.notificationAccess) {
                        "What's playing, with play, pause and skip."
                    } else {
                        "Needs notification access. Tap to turn it on."
                    },
                    onClick = if (state.notificationAccess) actions.pinMusic else actions.openNotificationAccess,
                )
            }
            SettingAction(
                title = if (PHOTOS_TILE_KEY in state.pinned) "change photos" else "pin photos tile",
                subtitle = "Pick photos for the tile to cycle through. Only the ones you pick are used.",
                onClick = actions.choosePhotos,
            )
            if (PEOPLE_TILE_KEY !in state.pinned) {
                SettingAction(
                    title = "pin people tile",
                    subtitle = if (state.contactsDenied) {
                        "Contacts access is off. Tap to turn it on in app settings."
                    } else {
                        "A mosaic of your contacts. Asks for contacts access."
                    },
                    onClick = if (state.contactsDenied) actions.openAppSettings else actions.pinPeople,
                )
            }

            SectionHeader("accent color")
            AccentColors.indices.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { i ->
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .background(AccentColors[i])
                                .then(if (i == state.accent) Modifier.border(3.dp, colors.foreground) else Modifier)
                                .clickable { actions.pickAccent(i) }
                        )
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    val accent = LocalAccent.current
    Spacer(Modifier.height(16.dp))
    Text(title, color = accent, fontSize = 16.sp, fontFamily = MetroFont)
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val accent = LocalAccent.current
    val colors = LocalMetroColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = colors.foreground, fontSize = 20.sp, fontFamily = MetroFont)
            Text(subtitle, color = colors.subtle, fontSize = 14.sp, fontFamily = MetroFont)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = accent),
        )
    }
}

@Composable
private fun SettingAction(title: String, subtitle: String, onClick: () -> Unit) {
    val colors = LocalMetroColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp)
    ) {
        Text(title, color = colors.foreground, fontSize = 20.sp, fontFamily = MetroFont)
        Text(subtitle, color = colors.subtle, fontSize = 14.sp, fontFamily = MetroFont)
    }
}
