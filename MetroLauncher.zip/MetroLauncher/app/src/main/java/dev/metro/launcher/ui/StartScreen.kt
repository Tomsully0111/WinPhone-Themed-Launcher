package dev.metro.launcher.ui

import android.text.format.DateFormat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.metro.launcher.data.AppEntry
import dev.metro.launcher.data.CLOCK_TILE_KEY
import dev.metro.launcher.data.TileSize
import dev.metro.launcher.data.TileSpec
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun StartScreen(
    tiles: List<TileSpec>,
    apps: Map<String, AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onUnpin: (String) -> Unit,
    onResize: (String) -> Unit,
    onMove: (String, Int) -> Unit,
    onOpenAppList: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    var editingKey by remember { mutableStateOf<String?>(null) }
    val visible = remember(tiles, apps) {
        tiles.filter { it.key == CLOCK_TILE_KEY || apps.containsKey(it.key) }
    }
    val placed = remember(visible) { packTiles(visible) }
    val rows = placed.maxOfOrNull { it.row + it.spec.size.rows } ?: 0

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            // Tapping empty space leaves tile-editing mode.
            .pointerInput(Unit) { detectTapGestures(onTap = { editingKey = null }) }
    ) {
        val sidePad = 12.dp
        val gap = 6.dp
        val unit = (maxWidth - sidePad * 2 - gap * 3) / 4

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = sidePad, vertical = 24.dp)
        ) {
            if (placed.isEmpty()) {
                Text(
                    "Swipe left, long-press an app, and choose \"pin to start\".",
                    color = Color.Gray,
                    fontSize = 16.sp,
                    fontFamily = MetroFont,
                )
            }

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (rows == 0) 0.dp else unit * rows + gap * (rows - 1))
            ) {
                for (p in placed) {
                    key(p.spec.key) {
                        val k = p.spec.key
                        Tile(
                            placed = p,
                            app = apps[k],
                            unit = unit,
                            gap = gap,
                            editing = editingKey == k,
                            dimmed = editingKey != null && editingKey != k,
                            onClick = {
                                if (editingKey != null) editingKey = null
                                else apps[k]?.let(onLaunch)
                            },
                            onLongClick = { editingKey = k },
                            onUnpin = { editingKey = null; onUnpin(k) },
                            onResize = { onResize(k) },
                            onMoveBack = { onMove(k, -1) },
                            onMoveForward = { onMove(k, 1) },
                        )
                    }
                }
            }

            Spacer(Modifier.height(32.dp))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "settings",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    fontFamily = MetroFont,
                    modifier = Modifier.clickable(onClick = onOpenSettings).padding(8.dp),
                )
                Spacer(Modifier.weight(1f))
                // The circled arrow that opens the app list, as on Windows Phone 8.1.
                Box(
                    Modifier
                        .size(44.dp)
                        .border(2.dp, Color.White, CircleShape)
                        .clickable(onClick = onOpenAppList),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("→", color = Color.White, fontSize = 22.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Tile(
    placed: PlacedTile,
    app: AppEntry?,
    unit: Dp,
    gap: Dp,
    editing: Boolean,
    dimmed: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onUnpin: () -> Unit,
    onResize: () -> Unit,
    onMoveBack: () -> Unit,
    onMoveForward: () -> Unit,
) {
    val accent = LocalAccent.current
    val size = placed.spec.size
    val width = unit * size.cols + gap * (size.cols - 1)
    val height = unit * size.rows + gap * (size.rows - 1)

    // Tiles tilt down slightly under your finger and grow a little while being edited.
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = when {
            pressed -> 0.94f
            editing -> 1.04f
            else -> 1f
        },
        label = "tileScale",
    )

    Box(
        Modifier
            .offset(x = (unit + gap) * placed.col, y = (unit + gap) * placed.row)
            .size(width, height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (dimmed) 0.45f else 1f
            }
            .background(accent)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick,
            )
    ) {
        if (placed.spec.key == CLOCK_TILE_KEY) {
            ClockTileContent(size)
        } else if (app != null) {
            AppTileContent(app, size, unit)
        }

        if (editing) {
            EditButton("✕", Modifier.align(Alignment.TopEnd), onUnpin)
            EditButton("⤢", Modifier.align(Alignment.BottomEnd), onResize)
            EditButton("‹", Modifier.align(Alignment.TopStart), onMoveBack)
            EditButton("›", Modifier.align(Alignment.BottomStart), onMoveForward)
        }
    }
}

@Composable
private fun AppTileContent(app: AppEntry, size: TileSize, unit: Dp) {
    Box(Modifier.fillMaxSize()) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .align(Alignment.Center)
                .size(if (size == TileSize.SMALL) unit * 0.5f else unit * 0.6f),
        )
        if (size != TileSize.SMALL) {
            Text(
                app.label,
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = MetroFont,
                maxLines = 1,
                modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
            )
        }
    }
}

/** A built-in live tile: updates on the minute. */
@Composable
private fun ClockTileContent(size: TileSize) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L)
        }
    }
    val timePattern = if (DateFormat.is24HourFormat(context)) "H:mm" else "h:mm"

    Column(
        Modifier.fillMaxSize().padding(10.dp),
        verticalArrangement = Arrangement.Bottom,
    ) {
        Text(
            now.format(DateTimeFormatter.ofPattern(timePattern)),
            color = Color.White,
            fontFamily = MetroFont,
            fontWeight = FontWeight.Light,
            fontSize = if (size == TileSize.SMALL) 20.sp else 44.sp,
        )
        if (size != TileSize.SMALL) {
            Text(
                now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")).lowercase(),
                color = Color.White,
                fontFamily = MetroFont,
                fontSize = 14.sp,
            )
        }
    }
}

@Composable
private fun EditButton(glyph: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .padding(2.dp)
            .size(26.dp)
            .background(Color.White, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(glyph, color = Color.Black, fontSize = 14.sp)
    }
}
