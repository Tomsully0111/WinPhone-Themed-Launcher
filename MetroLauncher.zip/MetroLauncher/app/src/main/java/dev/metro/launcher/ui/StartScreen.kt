package dev.metro.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import dev.metro.launcher.data.AppEntry
import dev.metro.launcher.data.BUILTIN_TILE_KEYS
import dev.metro.launcher.data.CALENDAR_TILE_KEY
import dev.metro.launcher.data.CLOCK_TILE_KEY
import dev.metro.launcher.data.MUSIC_TILE_KEY
import dev.metro.launcher.data.PEOPLE_TILE_KEY
import dev.metro.launcher.data.PHOTOS_TILE_KEY
import dev.metro.launcher.data.TileSpec
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.floor
import kotlin.math.roundToInt

private enum class TransitionMode { NONE, ENTER, EXIT }

private data class TileTransition(
    val mode: TransitionMode,
    val focusKey: String? = null,
    val id: Int = 0,
)

@Composable
fun StartScreen(
    tiles: List<TileSpec>,
    apps: Map<String, AppEntry>,
    columns: Int,
    liveTiles: Boolean,
    animate: Boolean,
    enterSignal: Int,
    liveData: LiveData,
    backgroundImage: ImageBitmap?,
    onLaunch: (AppEntry) -> Unit,
    onOpenBuiltin: (String) -> Unit,
    onUnpin: (String) -> Unit,
    onResize: (String) -> Unit,
    onMove: (String, String?) -> Unit,
    onMerge: (String, String) -> Unit,
    onRemoveFromFolder: (String, String) -> Unit,
    onOpenAppList: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val colors = LocalMetroColors.current
    var editingKey by remember { mutableStateOf<String?>(null) }
    var openFolderKey by remember { mutableStateOf<String?>(null) }

    // Hide tiles for uninstalled apps, and folders whose apps are all gone.
    val visible = remember(tiles, apps) {
        tiles.mapNotNull { tile ->
            when {
                tile.key in BUILTIN_TILE_KEYS -> tile
                tile.isFolder -> tile.copy(children = tile.children.filter { apps.containsKey(it) })
                    .takeIf { it.children.isNotEmpty() }
                apps.containsKey(tile.key) -> tile
                else -> null
            }
        }
    }
    val placed = remember(visible, columns) { packTiles(visible, columns) }
    val rows = placed.maxOfOrNull { it.row + it.spec.size.rows } ?: 0

    // ----- Fly-in / fly-out -----
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    var transition by remember { mutableStateOf(TileTransition(TransitionMode.NONE)) }
    var transitionCount by remember { mutableIntStateOf(0) }

    fun startTransition(mode: TransitionMode, focusKey: String? = null) {
        transitionCount += 1
        transition = TileTransition(mode, focusKey, transitionCount)
    }

    LaunchedEffect(enterSignal) {
        if (animate && enterSignal > 0) startTransition(TransitionMode.ENTER)
    }

    /** Tiles swing away, the tapped one last, then the app opens. */
    fun withExit(key: String, action: () -> Unit) {
        if (!animate) {
            action()
            return
        }
        startTransition(TransitionMode.EXIT, key)
        scope.launch {
            delay(330)
            action()
            // If nothing opened, bring the tiles back.
            delay(1_500)
            if (transition.mode == TransitionMode.EXIT &&
                lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
            ) {
                startTransition(TransitionMode.NONE)
            }
        }
    }

    BackHandler(enabled = editingKey != null) { editingKey = null }

    val backdrop = remember(backgroundImage) { backgroundImage?.let { BackdropState(it) } }

    CompositionLocalProvider(LocalBackdrop provides backdrop) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .onGloballyPositioned { coords ->
                    backdrop?.let {
                        it.origin = coords.positionInRoot()
                        it.size = coords.size
                    }
                }
                .systemBarsPadding()
                // Tapping empty space leaves tile-editing mode.
                .pointerInput(Unit) { detectTapGestures(onTap = { editingKey = null }) }
        ) {
            val sidePad = 12.dp
            val gap = 6.dp
            val unit = (maxWidth - sidePad * 2 - gap * (columns - 1)) / columns
            val density = LocalDensity.current
            val cellPx = with(density) { (unit + gap).toPx() }
            val gapPx = with(density) { gap.toPx() }

            /**
             * Drop in the middle of another tile to make (or add to) a folder.
             * Drop anywhere else to move the tile there.
             */
            fun handleDrop(dragKey: String, center: Offset) {
                val col = floor(center.x / cellPx).toInt()
                val row = floor(center.y / cellPx).toInt()
                val target = placed.firstOrNull { p ->
                    val w = p.spec.size.cols.coerceAtMost(columns)
                    p.spec.key != dragKey &&
                        row >= p.row && row < p.row + p.spec.size.rows &&
                        col >= p.col && col < p.col + w
                }
                if (target != null && dragKey !in BUILTIN_TILE_KEYS && target.spec.key !in BUILTIN_TILE_KEYS) {
                    val w = target.spec.size.cols.coerceAtMost(columns) * cellPx - gapPx
                    val h = target.spec.size.rows * cellPx - gapPx
                    val fx = (center.x - target.col * cellPx) / w
                    val fy = (center.y - target.row * cellPx) / h
                    if (fx in 0.25f..0.75f && fy in 0.25f..0.75f) {
                        editingKey = null
                        onMerge(dragKey, target.spec.key)
                        return
                    }
                }
                val before = placed
                    .filter { it.spec.key != dragKey }
                    .sortedWith(compareBy({ it.row }, { it.col }))
                    .firstOrNull { it.row > row || (it.row == row && it.col >= col) }
                onMove(dragKey, before?.spec?.key)
            }

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = sidePad, vertical = 24.dp)
            ) {
                if (placed.isEmpty()) {
                    Text(
                        "Swipe left, long-press an app, and choose \"pin to start\".",
                        color = colors.subtle,
                        fontSize = 16.sp,
                        fontFamily = MetroFont,
                    )
                }

                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(if (rows == 0) 0.dp else unit * rows + gap * (rows - 1))
                ) {
                    for (p in placed) {
                        key(p.spec.key) {
                            val spec = p.spec
                            val k = spec.key
                            val app = apps[k]
                            val live = liveTiles && editingKey == null
                            val seed = k.hashCode()

                            TileFrame(
                                placed = p,
                                unit = unit,
                                gap = gap,
                                columns = columns,
                                transition = transition,
                                order = (p.row + p.col / 2).coerceAtMost(10),
                                editing = editingKey == k,
                                dimmed = editingKey != null && editingKey != k,
                                onClick = {
                                    when {
                                        editingKey != null -> editingKey = null
                                        spec.isFolder -> openFolderKey = k
                                        k in BUILTIN_TILE_KEYS -> withExit(k) { onOpenBuiltin(k) }
                                        app != null -> withExit(k) { onLaunch(app) }
                                    }
                                },
                                onLongClick = { editingKey = k },
                                onUnpin = { editingKey = null; onUnpin(k) },
                                onResize = { onResize(k) },
                                onDragEnd = { center -> handleDrop(k, center) },
                            ) {
                                when {
                                    k == CLOCK_TILE_KEY -> ClockTile(spec.size, live, seed)
                                    k == CALENDAR_TILE_KEY ->
                                        CalendarTile(spec.size, live, seed, liveData.nextEvent, liveData.calendarAccess)
                                    k == MUSIC_TILE_KEY ->
                                        MusicTile(spec.size, liveData.nowPlaying, liveData.notificationAccess)
                                    k == PHOTOS_TILE_KEY -> PhotosTile(spec.size, liveData.photos, live, seed)
                                    k == PEOPLE_TILE_KEY ->
                                        PeopleTile(spec.size, liveData.people, liveData.contactsAccess, live, seed)
                                    spec.isFolder -> {
                                        val folderApps = spec.children.mapNotNull { apps[it] }
                                        val unread = folderApps.sumOf {
                                            liveData.notifications[it.component.packageName]?.count ?: 0
                                        }
                                        FolderTile(spec.size, folderApps, unread, unit)
                                    }
                                    app != null -> AppTile(
                                        app = app,
                                        size = spec.size,
                                        unit = unit,
                                        live = live,
                                        seed = seed,
                                        news = liveData.notifications[app.component.packageName],
                                        showPreviews = liveData.showPreviews,
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(32.dp))

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "settings",
                        color = colors.subtle,
                        fontSize = 18.sp,
                        fontFamily = MetroFont,
                        modifier = Modifier.clickable(onClick = onOpenSettings).padding(8.dp),
                    )
                    Spacer(Modifier.weight(1f))
                    // The circled arrow that opens the app list, as on Windows Phone 8.1.
                    Box(
                        Modifier
                            .size(44.dp)
                            .border(2.dp, colors.foreground, CircleShape)
                            .clickable(onClick = onOpenAppList),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("→", color = colors.foreground, fontSize = 22.sp)
                    }
                }
            }
        }

        val folder = openFolderKey?.let { key -> visible.firstOrNull { it.key == key } }
        if (folder != null) {
            FolderOverlay(
                apps = folder.children.mapNotNull { apps[it] },
                notifications = liveData.notifications,
                onLaunch = { app ->
                    openFolderKey = null
                    onLaunch(app)
                },
                onRemove = { app -> onRemoveFromFolder(folder.key, app.key) },
                onDismiss = { openFolderKey = null },
            )
        }
    }
}

/**
 * Positions one tile and gives it the Windows Phone touches: tilt when pressed,
 * the turnstile fly-in and fly-out, and drag-to-move while editing.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TileFrame(
    placed: PlacedTile,
    unit: Dp,
    gap: Dp,
    columns: Int,
    transition: TileTransition,
    order: Int,
    editing: Boolean,
    dimmed: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onUnpin: () -> Unit,
    onResize: () -> Unit,
    onDragEnd: (Offset) -> Unit,
    content: @Composable () -> Unit,
) {
    val size = placed.spec.size
    val cols = size.cols.coerceAtMost(columns)
    val width = unit * cols + gap * (cols - 1)
    val height = unit * size.rows + gap * (size.rows - 1)

    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = when {
            pressed -> 0.94f
            editing -> 1.04f
            else -> 1f
        },
        label = "tileScale",
    )

    // 0 = swung away, 1 = in place.
    val progress = remember { Animatable(1f) }
    LaunchedEffect(transition) {
        when (transition.mode) {
            TransitionMode.ENTER -> {
                progress.snapTo(0f)
                delay(order * 30L)
                progress.animateTo(1f, tween(320, easing = FastOutSlowInEasing))
            }
            TransitionMode.EXIT -> {
                delay(if (placed.spec.key == transition.focusKey) 190L else order * 18L)
                progress.animateTo(0f, tween(150))
            }
            TransitionMode.NONE -> progress.snapTo(1f)
        }
    }

    var drag by remember { mutableStateOf(Offset.Zero) }

    Box(
        Modifier
            .offset(x = (unit + gap) * placed.col, y = (unit + gap) * placed.row)
            .offset { IntOffset(drag.x.roundToInt(), drag.y.roundToInt()) }
            .zIndex(if (editing) 1f else 0f)
            .size(width, height)
            .graphicsLayer {
                val p = progress.value
                rotationY = (1f - p) * -75f
                transformOrigin = TransformOrigin(0f, 0.5f)
                cameraDistance = 12f * density
                alpha = p
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (dimmed) 0.45f else 1f
            }
            .pointerInput(editing, placed, unit, gap) {
                if (!editing) return@pointerInput
                detectDragGestures(
                    onDragEnd = {
                        val d = drag
                        drag = Offset.Zero
                        onDragEnd(
                            Offset(
                                (unit + gap).toPx() * placed.col + width.toPx() / 2f + d.x,
                                (unit + gap).toPx() * placed.row + height.toPx() / 2f + d.y,
                            )
                        )
                    },
                    onDragCancel = { drag = Offset.Zero },
                    onDrag = { change, amount ->
                        change.consume()
                        drag += amount
                    },
                )
            }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick,
            )
    ) {
        content()

        if (editing) {
            EditButton("✕", Modifier.align(Alignment.TopEnd), onUnpin)
            EditButton("⤢", Modifier.align(Alignment.BottomEnd), onResize)
        }
    }
}

@Composable
private fun EditButton(glyph: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .padding(2.dp)
            .size(26.dp)
            .background(Color.White, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(glyph, color = Color.Black, fontSize = 14.sp)
    }
}
