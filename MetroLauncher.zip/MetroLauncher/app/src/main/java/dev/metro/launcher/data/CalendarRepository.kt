package dev.metro.launcher.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat

data class NextEvent(
    val title: String,
    val begin: Long,
    val allDay: Boolean,
    val location: String?,
)

/** Reads only the next upcoming event, for the calendar tile. Nothing is stored. */
class CalendarRepository(private val context: Context) {

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    fun nextEvent(): NextEvent? {
        if (!hasPermission()) return null
        val now = System.currentTimeMillis()
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, now - DAY_MS)
            ContentUris.appendId(it, now + 7 * DAY_MS)
        }.build()
        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.EVENT_LOCATION,
        )
        return runCatching {
            context.contentResolver.query(
                uri,
                projection,
                "${CalendarContract.Instances.END} > ? AND ${CalendarContract.Instances.VISIBLE} = 1",
                arrayOf(now.toString()),
                "${CalendarContract.Instances.BEGIN} ASC",
            )?.use { c ->
                if (c.moveToFirst()) {
                    NextEvent(
                        title = c.getString(0)?.takeIf { it.isNotBlank() } ?: "(no title)",
                        begin = c.getLong(1),
                        allDay = c.getInt(3) == 1,
                        location = c.getString(4)?.takeIf { it.isNotBlank() },
                    )
                } else {
                    null
                }
            }
        }.getOrNull()
    }

    private companion object {
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
