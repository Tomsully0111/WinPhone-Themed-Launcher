package dev.metro.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.metro.launcher.LauncherViewModel
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun LauncherScreen(viewModel: LauncherViewModel, homeSignal: Int) {
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val tiles by viewModel.tiles.collectAsStateWithLifecycle()
    val accentIndex by viewModel.accent.collectAsStateWithLifecycle()
    val appsByKey = remember(apps) { apps.associateBy { it.key } }

    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    var showSettings by remember { mutableStateOf(false) }

    // Home button: slide back to the start screen.
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) pager.animateScrollToPage(0)
    }
    BackHandler(enabled = pager.currentPage == 1) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    val accent = AccentColors[accentIndex.coerceIn(AccentColors.indices)]

    MetroTheme(accent = accent) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                Box(
                    Modifier
                        .fillMaxSize()
                        // A light "turnstile" swing between the two pages.
                        .graphicsLayer {
                            val offset = (pager.currentPage - page) + pager.currentPageOffsetFraction
                            rotationY = offset * 20f
                            transformOrigin = TransformOrigin(0f, 0.5f)
                            cameraDistance = 12f * density
                            alpha = 1f - abs(offset).coerceIn(0f, 1f) * 0.5f
                        }
                ) {
                    if (page == 0) {
                        StartScreen(
                            tiles = tiles,
                            apps = appsByKey,
                            onLaunch = viewModel.repo::launch,
                            onUnpin = viewModel::unpin,
                            onResize = viewModel::resize,
                            onMove = viewModel::move,
                            onOpenAppList = { scope.launch { pager.animateScrollToPage(1) } },
                            onOpenSettings = { showSettings = true },
                        )
                    } else {
                        AppListScreen(
                            apps = apps,
                            onLaunch = viewModel.repo::launch,
                            onPin = { app ->
                                viewModel.pin(app.key)
                                scope.launch { pager.animateScrollToPage(0) }
                            },
                            onAppInfo = viewModel.repo::openAppInfo,
                            onUninstall = viewModel.repo::uninstall,
                        )
                    }
                }
            }
        }

        if (showSettings) {
            AccentPicker(
                current = accentIndex,
                onPick = { viewModel.setAccent(it); showSettings = false },
                onDismiss = { showSettings = false },
            )
        }
    }
}
