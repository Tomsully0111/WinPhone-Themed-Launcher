package dev.metro.launcher.ui

import android.Manifest
import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.metro.launcher.LauncherViewModel
import dev.metro.launcher.data.CALENDAR_TILE_KEY
import dev.metro.launcher.data.CLOCK_TILE_KEY
import dev.metro.launcher.data.MUSIC_TILE_KEY
import dev.metro.launcher.data.PEOPLE_TILE_KEY
import dev.metro.launcher.data.PHOTOS_TILE_KEY
import dev.metro.launcher.media.MediaHub
import dev.metro.launcher.notifications.NotificationHub
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun LauncherScreen(viewModel: LauncherViewModel, homeSignal: Int) {
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val tiles by viewModel.tiles.collectAsStateWithLifecycle()
    val accentIndex by viewModel.accent.collectAsStateWithLifecycle()
    val liveTiles by viewModel.liveTiles.collectAsStateWithLifecycle()
    val showPreviews by viewModel.showPreviews.collectAsStateWithLifecycle()
    val columns by viewModel.columns.collectAsStateWithLifecycle()
    val lightTheme by viewModel.lightTheme.collectAsStateWithLifecycle()
    val seen by viewModel.seen.collectAsStateWithLifecycle()
    val recent by viewModel.recent.collectAsStateWithLifecycle()
    val nextEvent by viewModel.nextEvent.collectAsStateWithLifecycle()
    val backgrounds by viewModel.backgrounds.collectAsStateWithLifecycle()
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val notifications by NotificationHub.byPackage.collectAsStateWithLifecycle()
    val nowPlaying by MediaHub.nowPlaying.collectAsStateWithLifecycle()
    val appsByKey = remember(apps) { apps.associateBy { it.key } }

    val context = LocalContext.current
    // Respect "Remove animations" in Android's accessibility settings.
    val animationsOff = remember {
        Settings.Global.getFloat(
            context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f,
        ) == 0f
    }
    val animate = liveTiles && !animationsOff

    var notificationAccess by remember { mutableStateOf(viewModel.hasNotificationAccess()) }
    var calendarAccess by remember { mutableStateOf(viewModel.calendar.hasPermission()) }
    var contactsAccess by remember { mutableStateOf(viewModel.people.hasPermission()) }
    var calendarDenied by remember { mutableStateOf(false) }
    var contactsDenied by remember { mutableStateOf(false) }
    var enterSignal by remember { mutableIntStateOf(0) }

    // Coming back to the launcher: re-check access (it can change in Android settings),
    // refresh live data, and fly the tiles in.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        notificationAccess = viewModel.hasNotificationAccess()
        calendarAccess = viewModel.calendar.hasPermission()
        contactsAccess = viewModel.people.hasPermission()
        if (calendarAccess) calendarDenied = false
        if (contactsAccess) contactsDenied = false
        if (notificationAccess) MediaHub.start(context.applicationContext) else MediaHub.stop()
        viewModel.refreshCalendar()
        if (contactsAccess) viewModel.refreshPeople()
        enterSignal += 1
    }

    val calendarPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        calendarAccess = granted
        calendarDenied = !granted
        if (granted) {
            viewModel.pinBuiltin(CALENDAR_TILE_KEY)
            viewModel.refreshCalendar()
        }
    }
    val contactsPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        contactsAccess = granted
        contactsDenied = !granted
        if (granted) {
            viewModel.pinBuiltin(PEOPLE_TILE_KEY)
            viewModel.refreshPeople()
        }
    }
    // Android's photo picker: no permission, and the launcher only sees what you pick.
    val backgroundPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 20)
    ) { uris -> if (uris.isNotEmpty()) viewModel.setBackgrounds(uris) }
    val photosPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(maxItems = 12)
    ) { uris -> if (uris.isNotEmpty()) viewModel.setPhotos(uris) }

    fun startSafely(intent: Intent) {
        runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun openBuiltin(key: String) {
        when (key) {
            CLOCK_TILE_KEY -> startSafely(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            CALENDAR_TILE_KEY -> startSafely(
                Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI.buildUpon().appendPath("time").build())
            )
            MUSIC_TILE_KEY -> {
                val playing = nowPlaying?.packageName?.let { context.packageManager.getLaunchIntentForPackage(it) }
                startSafely(playing ?: Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
            }
            PHOTOS_TILE_KEY -> startSafely(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
            PEOPLE_TILE_KEY -> startSafely(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS))
        }
    }

    // Dark status bar icons on the light theme, light icons on the dark one.
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { window ->
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = lightTheme
                isAppearanceLightNavigationBars = lightTheme
            }
        }
    }

    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    var showSettings by remember { mutableStateOf(false) }

    // Home button: slide back to the start screen.
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) pager.animateScrollToPage(0)
    }
    BackHandler(enabled = pager.currentPage == 1) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    val accent = AccentColors[accentIndex.coerceIn(AccentColors.indices)]
    val liveData = LiveData(
        notifications = if (notificationAccess) notifications else emptyMap(),
        showPreviews = showPreviews,
        notificationAccess = notificationAccess,
        nextEvent = nextEvent,
        calendarAccess = calendarAccess,
        nowPlaying = if (notificationAccess) nowPlaying else null,
        photos = photos,
        people = if (contactsAccess) contacts else emptyList(),
        contactsAccess = contactsAccess,
    )

    MetroTheme(accent = accent, light = lightTheme) {
        val colors = LocalMetroColors.current
        Box(Modifier.fillMaxSize().background(colors.background)) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                Box(
                    Modifier
                        .fillMaxSize()
                        // A light "turnstile" swing between the two pages.
                        .graphicsLayer {
                            val offset = (pager.currentPage - page) + pager.currentPageOffsetFraction
                            rotationY = offset * 20f
                            transformOrigin = TransformOrigin(0f, 0.5f)
                            cameraDistance = 12f * density
                            alpha = 1f - abs(offset).coerceIn(0f, 1f) * 0.5f
                        }
                ) {
                    if (page == 0) {
                        StartScreen(
                            tiles = tiles,
                            apps = appsByKey,
                            columns = columns,
                            liveTiles = animate,
                            animate = animate,
                            enterSignal = enterSignal,
                            liveData = liveData,
                            backgroundFiles = backgrounds,
                            onLaunch = viewModel::launch,
                            onOpenBuiltin = ::openBuiltin,
                            onUnpin = viewModel::unpin,
                            onResize = viewModel::resize,
                            onMove = viewModel::move,
                            onMerge = viewModel::merge,
                            onRemoveFromFolder = viewModel::removeFromFolder,
                            onOpenAppList = { scope.launch { pager.animateScrollToPage(1) } },
                            onOpenSettings = { showSettings = true },
                        )
                    } else {
                        AppListScreen(
                            apps = apps,
                            onLaunch = viewModel::launch,
                            onPin = { app ->
                                viewModel.pin(app.key)
                                scope.launch { pager.animateScrollToPage(0) }
                            },
                            onAppInfo = viewModel.repo::openAppInfo,
                            onUninstall = viewModel.repo::uninstall,
                            // Hands the search to your browser; the launcher itself stays offline.
                            onWebSearch = { q ->
                                startSafely(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                            },
                            isNew = { app -> viewModel.isNew(app, seen) },
                            recentKeys = recent,
                        )
                    }
                }
            }
        }

        if (showSettings) {
            SettingsDialog(
                state = SettingsState(
                    accent = accentIndex,
                    liveTiles = liveTiles,
                    moreTiles = columns > 4,
                    lightTheme = lightTheme,
                    backgroundCount = backgrounds.size,
                    notificationAccess = notificationAccess,
                    showPreviews = showPreviews,
                    pinned = tiles.map { it.key }.toSet(),
                    calendarDenied = calendarDenied,
                    contactsDenied = contactsDenied,
                ),
                actions = SettingsActions(
                    pickAccent = viewModel::setAccent,
                    setLiveTiles = viewModel::setLiveTiles,
                    setMoreTiles = viewModel::setMoreTiles,
                    setLightTheme = viewModel::setLightTheme,
                    chooseBackground = {
                        backgroundPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    removeBackground = viewModel::clearBackground,
                    openNotificationAccess = {
                        startSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    },
                    setShowPreviews = viewModel::setShowPreviews,
                    pinClock = { viewModel.pinBuiltin(CLOCK_TILE_KEY) },
                    pinCalendar = {
                        if (calendarAccess) {
                            viewModel.pinBuiltin(CALENDAR_TILE_KEY)
                            viewModel.refreshCalendar()
                        } else {
                            calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                        }
                    },
                    pinMusic = { viewModel.pinBuiltin(MUSIC_TILE_KEY) },
                    choosePhotos = {
                        photosPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    pinPeople = {
                        if (contactsAccess) {
                            viewModel.pinBuiltin(PEOPLE_TILE_KEY)
                            viewModel.refreshPeople()
                        } else {
                            contactsPermission.launch(Manifest.permission.READ_CONTACTS)
                        }
                    },
                    openAppSettings = {
                        startSafely(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null),
                            )
                        )
                    },
                    dismiss = { showSettings = false },
                ),
            )
        }
    }
}
