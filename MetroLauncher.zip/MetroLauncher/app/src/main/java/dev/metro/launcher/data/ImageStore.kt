package dev.metro.launcher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import java.io.FileOutputStream

/**
 * Keeps scaled-down private copies of the photos you pick, so the launcher never needs
 * access to your photo library. Picked through Android's photo picker, which needs no permission.
 */
class ImageStore(private val context: Context) {

    private val backgroundFile: File get() = File(context.filesDir, "start_background.jpg")
    private val photosDir: File get() = File(context.filesDir, "photos").apply { mkdirs() }

    fun loadBackground(): ImageBitmap? =
        backgroundFile.takeIf { it.exists() }
            ?.let { BitmapFactory.decodeFile(it.absolutePath)?.asImageBitmap() }

    fun saveBackground(uri: Uri): ImageBitmap? {
        val bitmap = decodeScaled(uri, maxDimension = 2400) ?: return null
        FileOutputStream(backgroundFile).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        return bitmap.asImageBitmap()
    }

    fun clearBackground() {
        backgroundFile.delete()
    }

    fun listPhotos(): List<File> =
        photosDir.listFiles()?.filter { it.extension == "jpg" }?.sortedBy { it.name } ?: emptyList()

    fun savePhotos(uris: List<Uri>): List<File> {
        val decoded = uris.mapNotNull { decodeScaled(it, maxDimension = 1080) }
        if (decoded.isEmpty()) return listPhotos()
        photosDir.listFiles()?.forEach { it.delete() }
        // A fresh timestamp in the names lets the tile notice the set has changed.
        val stamp = System.currentTimeMillis()
        decoded.forEachIndexed { i, bitmap ->
            val file = File(photosDir, "photo_${stamp}_${i.toString().padStart(2, '0')}.jpg")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        }
        return listPhotos()
    }

    private fun decodeScaled(uri: Uri, maxDimension: Int): Bitmap? = runCatching {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val w = info.size.width
            val h = info.size.height
            val scale = maxOf(w, h).toFloat() / maxDimension
            if (scale > 1f) decoder.setTargetSize((w / scale).toInt(), (h / scale).toInt())
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }.getOrNull()
}
