package dev.metro.launcher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import java.io.FileOutputStream

/**
 * Keeps scaled-down private copies of the photos you pick, so the launcher never needs
 * access to your photo library. Picked through Android's photo picker, which needs no permission.
 */
class ImageStore(private val context: Context) {

    // Single background from before slideshows existed; moved into backgroundsDir on first read.
    private val legacyBackground: File get() = File(context.filesDir, "start_background.jpg")
    private val backgroundsDir: File get() = File(context.filesDir, "backgrounds").apply { mkdirs() }
    private val photosDir: File get() = File(context.filesDir, "photos").apply { mkdirs() }

    /** Start background photos, in the order you picked them. One photo means no slideshow. */
    fun listBackgrounds(): List<File> {
        if (legacyBackground.exists()) legacyBackground.renameTo(File(backgroundsDir, "bg_0_00.jpg"))
        return list(backgroundsDir)
    }

    fun saveBackgrounds(uris: List<Uri>): List<File> =
        saveSet(backgroundsDir, prefix = "bg", uris = uris, maxDimension = 2000)

    fun clearBackgrounds() {
        legacyBackground.delete()
        backgroundsDir.listFiles()?.forEach { it.delete() }
    }

    fun listPhotos(): List<File> = list(photosDir)

    fun savePhotos(uris: List<Uri>): List<File> =
        saveSet(photosDir, prefix = "photo", uris = uris, maxDimension = 1080)

    private fun list(dir: File): List<File> =
        dir.listFiles()?.filter { it.extension == "jpg" }?.sortedBy { it.name } ?: emptyList()

    private fun saveSet(dir: File, prefix: String, uris: List<Uri>, maxDimension: Int): List<File> {
        val decoded = uris.mapNotNull { decodeScaled(it, maxDimension) }
        if (decoded.isEmpty()) return list(dir)
        dir.listFiles()?.forEach { it.delete() }
        // A fresh timestamp in the names lets the screen notice the set has changed.
        val stamp = System.currentTimeMillis()
        decoded.forEachIndexed { i, bitmap ->
            val file = File(dir, "${prefix}_${stamp}_${i.toString().padStart(2, '0')}.jpg")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        }
        return list(dir)
    }

    private fun decodeScaled(uri: Uri, maxDimension: Int): Bitmap? = runCatching {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val w = info.size.width
            val h = info.size.height
            val scale = maxOf(w, h).toFloat() / maxDimension
            if (scale > 1f) decoder.setTargetSize((w / scale).toInt(), (h / scale).toInt())
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }.getOrNull()
}
