package dev.metro.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** The classic Metro accent palette. */
val AccentColors = listOf(
    Color(0xFF1BA1E2), // cyan
    Color(0xFF0050EF), // cobalt
    Color(0xFF00ABA9), // teal
    Color(0xFF60A917), // green
    Color(0xFFA4C400), // lime
    Color(0xFFE3C800), // yellow
    Color(0xFFF0A30A), // amber
    Color(0xFFFA6800), // orange
    Color(0xFFE51400), // red
    Color(0xFFD80073), // magenta
    Color(0xFFAA00FF), // violet
    Color(0xFF6A00FF), // indigo
    Color(0xFF825A2C), // brown
    Color(0xFF647687), // steel
)

/**
 * Swap this for Selawik (Microsoft's open-source, Segoe-like font, SIL OFL licensed):
 * put the .ttf files in res/font and use FontFamily(Font(R.font.selawik_light, FontWeight.Light), ...).
 */
val MetroFont: FontFamily = FontFamily.SansSerif

/** Colors for everything except tiles, which always use white text. */
data class MetroColors(
    val isLight: Boolean,
    val background: Color,
    val foreground: Color,
    val subtle: Color,
    val panel: Color,
    val field: Color,
    val fieldHint: Color,
)

private val DarkMetro = MetroColors(
    isLight = false,
    background = Color.Black,
    foreground = Color.White,
    subtle = Color(0xFF9A9A9A),
    panel = Color(0xFF1F1F1F),
    field = Color(0xFF2A2A2A),
    fieldHint = Color(0xFFAAAAAA),
)

private val LightMetro = MetroColors(
    isLight = true,
    background = Color.White,
    foreground = Color.Black,
    subtle = Color(0xFF666666),
    panel = Color(0xFFF2F2F2),
    field = Color(0xFFE6E6E6),
    fieldHint = Color(0xFF6E6E6E),
)

val LocalAccent = staticCompositionLocalOf { AccentColors[0] }
val LocalMetroColors = staticCompositionLocalOf { DarkMetro }

@Composable
fun MetroTheme(accent: Color, light: Boolean, content: @Composable () -> Unit) {
    val colors = if (light) LightMetro else DarkMetro
    MaterialTheme(
        colorScheme = if (light) {
            lightColorScheme(
                primary = accent,
                background = colors.background,
                surface = colors.panel,
                onBackground = colors.foreground,
                onSurface = colors.foreground,
            )
        } else {
            darkColorScheme(
                primary = accent,
                background = colors.background,
                surface = colors.panel,
                onBackground = colors.foreground,
                onSurface = colors.foreground,
            )
        },
    ) {
        CompositionLocalProvider(
            LocalAccent provides accent,
            LocalMetroColors provides colors,
            content = content,
        )
    }
}
