package dev.metro.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** The classic Metro accent palette. */
val AccentColors = listOf(
    Color(0xFF1BA1E2), // cyan
    Color(0xFF0050EF), // cobalt
    Color(0xFF00ABA9), // teal
    Color(0xFF60A917), // green
    Color(0xFFA4C400), // lime
    Color(0xFFE3C800), // yellow
    Color(0xFFF0A30A), // amber
    Color(0xFFFA6800), // orange
    Color(0xFFE51400), // red
    Color(0xFFD80073), // magenta
    Color(0xFFAA00FF), // violet
    Color(0xFF6A00FF), // indigo
    Color(0xFF825A2C), // brown
    Color(0xFF647687), // steel
)

/**
 * Swap this for Selawik (Microsoft's open-source, Segoe-like font, SIL OFL licensed):
 * put the .ttf files in res/font and use FontFamily(Font(R.font.selawik_light, FontWeight.Light), ...).
 */
val MetroFont: FontFamily = FontFamily.SansSerif

val LocalAccent = staticCompositionLocalOf { AccentColors[0] }

@Composable
fun MetroTheme(accent: Color, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            background = Color.Black,
            surface = Color(0xFF1F1F1F),
            onBackground = Color.White,
            onSurface = Color.White,
        ),
    ) {
        CompositionLocalProvider(LocalAccent provides accent, content = content)
    }
}
