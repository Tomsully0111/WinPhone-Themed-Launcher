package dev.metro.launcher.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Tile sizes in grid units. */
enum class TileSize(val cols: Int, val rows: Int) {
    SMALL(1, 1), MEDIUM(2, 2), WIDE(4, 2);

    fun next(): TileSize = entries[(ordinal + 1) % entries.size]
}

const val FOLDER_PREFIX = "folder:"

/** A tile on the start screen. Folder tiles keep their apps' keys in [children]. */
data class TileSpec(
    val key: String,
    val size: TileSize,
    val children: List<String> = emptyList(),
) {
    val isFolder: Boolean get() = key.startsWith(FOLDER_PREFIX)
}

const val CLOCK_TILE_KEY = "builtin:clock"
const val CALENDAR_TILE_KEY = "builtin:calendar"
const val MUSIC_TILE_KEY = "builtin:music"
const val PHOTOS_TILE_KEY = "builtin:photos"
const val PEOPLE_TILE_KEY = "builtin:people"
val BUILTIN_TILE_KEYS = setOf(
    CLOCK_TILE_KEY, CALENDAR_TILE_KEY, MUSIC_TILE_KEY, PHOTOS_TILE_KEY, PEOPLE_TILE_KEY,
)

/** Saves the start screen layout and settings in SharedPreferences. */
class TileStore(context: Context) {

    private val prefs = context.getSharedPreferences("metro", Context.MODE_PRIVATE)

    fun loadTiles(): List<TileSpec> {
        val raw = prefs.getString("tiles", null)
            ?: return listOf(TileSpec(CLOCK_TILE_KEY, TileSize.WIDE))
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                val kids = obj.optJSONArray("children")
                TileSpec(
                    key = obj.getString("key"),
                    size = TileSize.valueOf(obj.getString("size")),
                    children = if (kids == null) emptyList() else (0 until kids.length()).map { kids.getString(it) },
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveTiles(tiles: List<TileSpec>) {
        val array = JSONArray()
        tiles.forEach { tile ->
            val obj = JSONObject().put("key", tile.key).put("size", tile.size.name)
            if (tile.children.isNotEmpty()) obj.put("children", JSONArray(tile.children))
            array.put(obj)
        }
        prefs.edit().putString("tiles", array.toString()).apply()
    }

    fun loadAccent(): Int = prefs.getInt("accent", 0)
    fun saveAccent(index: Int) = prefs.edit().putInt("accent", index).apply()

    fun loadLiveTiles(): Boolean = prefs.getBoolean("liveTiles", true)
    fun saveLiveTiles(enabled: Boolean) = prefs.edit().putBoolean("liveTiles", enabled).apply()

    /** Off by default: tiles show how many notifications, not what they say. */
    fun loadShowPreviews(): Boolean = prefs.getBoolean("showPreviews", false)
    fun saveShowPreviews(enabled: Boolean) = prefs.edit().putBoolean("showPreviews", enabled).apply()

    /** 4 grid units across (two medium tiles) or 6 ("show more tiles": three medium tiles). */
    fun loadColumns(): Int = prefs.getInt("columns", 4)
    fun saveColumns(columns: Int) = prefs.edit().putInt("columns", columns).apply()

    fun loadLightTheme(): Boolean = prefs.getBoolean("lightTheme", false)
    fun saveLightTheme(enabled: Boolean) = prefs.edit().putBoolean("lightTheme", enabled).apply()

    /** Apps you've opened since installing, so they lose their "new" label. */
    fun loadSeen(): Set<String> = HashSet(prefs.getStringSet("seen", emptySet()) ?: emptySet())
    fun saveSeen(keys: Set<String>) = prefs.edit().putStringSet("seen", HashSet(keys)).apply()

    /** Apps opened from the launcher, most recent first. */
    fun loadRecent(): List<String> = runCatching {
        val array = JSONArray(prefs.getString("recent", "[]"))
        (0 until array.length()).map { array.getString(it) }
    }.getOrDefault(emptyList())

    fun saveRecent(keys: List<String>) = prefs.edit().putString("recent", JSONArray(keys).toString()).apply()
}
