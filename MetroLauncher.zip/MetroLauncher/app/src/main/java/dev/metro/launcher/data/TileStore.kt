package dev.metro.launcher.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Tile sizes in grid units on a 4-column start screen. */
enum class TileSize(val cols: Int, val rows: Int) {
    SMALL(1, 1), MEDIUM(2, 2), WIDE(4, 2);

    fun next(): TileSize = entries[(ordinal + 1) % entries.size]
}

data class TileSpec(val key: String, val size: TileSize)

const val CLOCK_TILE_KEY = "builtin:clock"

/** Saves the start screen layout and accent color in SharedPreferences. */
class TileStore(context: Context) {

    private val prefs = context.getSharedPreferences("metro", Context.MODE_PRIVATE)

    fun loadTiles(): List<TileSpec> {
        val raw = prefs.getString("tiles", null)
            ?: return listOf(TileSpec(CLOCK_TILE_KEY, TileSize.WIDE))
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                TileSpec(obj.getString("key"), TileSize.valueOf(obj.getString("size")))
            }
        }.getOrDefault(emptyList())
    }

    fun saveTiles(tiles: List<TileSpec>) {
        val array = JSONArray()
        tiles.forEach { array.put(JSONObject().put("key", it.key).put("size", it.size.name)) }
        prefs.edit().putString("tiles", array.toString()).apply()
    }

    fun loadAccent(): Int = prefs.getInt("accent", 0)

    fun saveAccent(index: Int) {
        prefs.edit().putInt("accent", index).apply()
    }
}
