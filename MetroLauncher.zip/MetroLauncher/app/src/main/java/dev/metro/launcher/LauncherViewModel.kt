package dev.metro.launcher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.metro.launcher.data.AppEntry
import dev.metro.launcher.data.AppRepository
import dev.metro.launcher.data.TileSize
import dev.metro.launcher.data.TileSpec
import dev.metro.launcher.data.TileStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    val repo = AppRepository(application)
    private val store = TileStore(application)

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val _tiles = MutableStateFlow(store.loadTiles())
    val tiles: StateFlow<List<TileSpec>> = _tiles.asStateFlow()

    private val _accent = MutableStateFlow(store.loadAccent())
    val accent: StateFlow<Int> = _accent.asStateFlow()

    private var loadJob: Job? = null
    private val packageCallback = repo.registerCallback { refresh() }

    init { refresh() }

    fun refresh() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _apps.value = withContext(Dispatchers.Default) { repo.loadApps() }
        }
    }

    fun pin(key: String) {
        if (_tiles.value.none { it.key == key }) {
            updateTiles(_tiles.value + TileSpec(key, TileSize.MEDIUM))
        }
    }

    fun unpin(key: String) = updateTiles(_tiles.value.filterNot { it.key == key })

    fun resize(key: String) = updateTiles(
        _tiles.value.map { if (it.key == key) it.copy(size = it.size.next()) else it }
    )

    fun move(key: String, delta: Int) {
        val list = _tiles.value.toMutableList()
        val from = list.indexOfFirst { it.key == key }
        val to = from + delta
        if (from < 0 || to !in list.indices) return
        Collections.swap(list, from, to)
        updateTiles(list)
    }

    fun setAccent(index: Int) {
        _accent.value = index
        store.saveAccent(index)
    }

    private fun updateTiles(tiles: List<TileSpec>) {
        _tiles.value = tiles
        store.saveTiles(tiles)
    }

    override fun onCleared() {
        repo.unregisterCallback(packageCallback)
    }
}
