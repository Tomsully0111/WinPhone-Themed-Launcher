package dev.metro.launcher

import android.app.Application
import android.net.Uri
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.metro.launcher.data.AppEntry
import dev.metro.launcher.data.AppRepository
import dev.metro.launcher.data.BUILTIN_TILE_KEYS
import dev.metro.launcher.data.CalendarRepository
import dev.metro.launcher.data.FOLDER_PREFIX
import dev.metro.launcher.data.ImageStore
import dev.metro.launcher.data.NextEvent
import dev.metro.launcher.data.PHOTOS_TILE_KEY
import dev.metro.launcher.data.PeopleRepository
import dev.metro.launcher.data.Person
import dev.metro.launcher.data.TileSize
import dev.metro.launcher.data.TileSpec
import dev.metro.launcher.data.TileStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    val repo = AppRepository(application)
    val calendar = CalendarRepository(application)
    val people = PeopleRepository(application)
    private val images = ImageStore(application)
    private val store = TileStore(application)

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val _tiles = MutableStateFlow(store.loadTiles())
    val tiles: StateFlow<List<TileSpec>> = _tiles.asStateFlow()

    private val _accent = MutableStateFlow(store.loadAccent())
    val accent: StateFlow<Int> = _accent.asStateFlow()

    private val _liveTiles = MutableStateFlow(store.loadLiveTiles())
    val liveTiles: StateFlow<Boolean> = _liveTiles.asStateFlow()

    private val _showPreviews = MutableStateFlow(store.loadShowPreviews())
    val showPreviews: StateFlow<Boolean> = _showPreviews.asStateFlow()

    private val _columns = MutableStateFlow(store.loadColumns())
    val columns: StateFlow<Int> = _columns.asStateFlow()

    private val _lightTheme = MutableStateFlow(store.loadLightTheme())
    val lightTheme: StateFlow<Boolean> = _lightTheme.asStateFlow()

    private val _seen = MutableStateFlow(store.loadSeen())
    val seen: StateFlow<Set<String>> = _seen.asStateFlow()

    private val _recent = MutableStateFlow(store.loadRecent())
    val recent: StateFlow<List<String>> = _recent.asStateFlow()

    private val _nextEvent = MutableStateFlow<NextEvent?>(null)
    val nextEvent: StateFlow<NextEvent?> = _nextEvent.asStateFlow()

    private val _backgrounds = MutableStateFlow<List<File>>(emptyList())
    val backgrounds: StateFlow<List<File>> = _backgrounds.asStateFlow()

    private val _photos = MutableStateFlow<List<File>>(emptyList())
    val photos: StateFlow<List<File>> = _photos.asStateFlow()

    private val _contacts = MutableStateFlow<List<Person>>(emptyList())
    val contacts: StateFlow<List<Person>> = _contacts.asStateFlow()

    private var loadJob: Job? = null
    private var calendarJob: Job? = null
    private var peopleJob: Job? = null
    private val packageCallback = repo.registerCallback { refresh() }

    init {
        refresh()
        viewModelScope.launch {
            _backgrounds.value = withContext(Dispatchers.IO) { images.listBackgrounds() }
            _photos.value = withContext(Dispatchers.IO) { images.listPhotos() }
        }
        refreshPeople()
        viewModelScope.launch {
            while (true) {
                refreshCalendar()
                delay(5 * 60_000L)
            }
        }
    }

    // ----- Apps -----

    fun refresh() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _apps.value = withContext(Dispatchers.Default) { repo.loadApps() }
        }
    }

    fun launch(app: AppEntry) {
        markSeen(app.key)
        recordRecent(app.key)
        repo.launch(app)
    }

    private fun recordRecent(key: String) {
        val updated = (listOf(key) + _recent.value.filterNot { it == key }).take(MAX_RECENT)
        _recent.value = updated
        store.saveRecent(updated)
    }

    /** Recently installed apps you haven't opened yet. */
    fun isNew(app: AppEntry, seen: Set<String>): Boolean =
        app.installedAt > 0 &&
            System.currentTimeMillis() - app.installedAt < NEW_APP_WINDOW_MS &&
            app.key !in seen

    private fun markSeen(key: String) {
        if (key in _seen.value) return
        val updated = _seen.value + key
        _seen.value = updated
        store.saveSeen(updated)
    }

    // ----- Live data -----

    fun refreshCalendar() {
        calendarJob?.cancel()
        calendarJob = viewModelScope.launch {
            _nextEvent.value = withContext(Dispatchers.IO) { calendar.nextEvent() }
        }
    }

    fun refreshPeople() {
        peopleJob?.cancel()
        peopleJob = viewModelScope.launch {
            _contacts.value = withContext(Dispatchers.IO) { people.load() }
        }
    }

    fun hasNotificationAccess(): Boolean {
        val app = getApplication<Application>()
        return NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName)
    }

    // ----- Tiles -----

    private fun isPinned(key: String): Boolean =
        _tiles.value.any { it.key == key || key in it.children }

    fun pin(key: String) {
        if (!isPinned(key)) updateTiles(_tiles.value + TileSpec(key, TileSize.MEDIUM))
    }

    fun pinBuiltin(key: String) {
        if (!isPinned(key)) updateTiles(_tiles.value + TileSpec(key, TileSize.WIDE))
    }

    fun unpin(key: String) = updateTiles(_tiles.value.filterNot { it.key == key })

    fun resize(key: String) = updateTiles(
        _tiles.value.map { if (it.key == key) it.copy(size = it.size.next()) else it }
    )

    /** Moves a tile so it sits just before [beforeKey], or at the end when that's null. */
    fun move(key: String, beforeKey: String?) {
        val list = _tiles.value.toMutableList()
        val from = list.indexOfFirst { it.key == key }
        if (from < 0) return
        val tile = list.removeAt(from)
        val to = beforeKey?.let { b -> list.indexOfFirst { it.key == b } }?.takeIf { it >= 0 } ?: list.size
        list.add(to, tile)
        updateTiles(list)
    }

    /** Dropping one tile onto another makes a folder, or adds to an existing one. */
    fun merge(dragKey: String, targetKey: String) {
        if (dragKey == targetKey || dragKey in BUILTIN_TILE_KEYS || targetKey in BUILTIN_TILE_KEYS) return
        val list = _tiles.value
        val drag = list.firstOrNull { it.key == dragKey } ?: return
        val target = list.firstOrNull { it.key == targetKey } ?: return
        val dragApps = if (drag.isFolder) drag.children else listOf(drag.key)
        val merged = if (target.isFolder) {
            target.copy(children = (target.children + dragApps).distinct())
        } else {
            TileSpec(
                key = FOLDER_PREFIX + System.currentTimeMillis(),
                size = target.size,
                children = (listOf(target.key) + dragApps).distinct(),
            )
        }
        updateTiles(
            list.mapNotNull {
                when (it.key) {
                    dragKey -> null
                    targetKey -> merged
                    else -> it
                }
            }
        )
    }

    /** Takes an app out of a folder and puts it on the start screen right after it. */
    fun removeFromFolder(folderKey: String, appKey: String) {
        val list = _tiles.value.toMutableList()
        val index = list.indexOfFirst { it.key == folderKey }
        if (index < 0) return
        val folder = list[index]
        val remaining = folder.children - appKey
        when (remaining.size) {
            0 -> list.removeAt(index)
            1 -> list[index] = TileSpec(remaining[0], folder.size)
            else -> list[index] = folder.copy(children = remaining)
        }
        list.add((index + 1).coerceAtMost(list.size), TileSpec(appKey, TileSize.MEDIUM))
        updateTiles(list)
    }

    private fun updateTiles(tiles: List<TileSpec>) {
        _tiles.value = tiles
        store.saveTiles(tiles)
    }

    // ----- Pictures -----

    /** One photo for a still background, or several for a slideshow. */
    fun setBackgrounds(uris: List<Uri>) {
        viewModelScope.launch {
            _backgrounds.value = withContext(Dispatchers.IO) { images.saveBackgrounds(uris) }
        }
    }

    fun clearBackground() {
        _backgrounds.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) { images.clearBackgrounds() }
    }

    fun setPhotos(uris: List<Uri>) {
        viewModelScope.launch {
            _photos.value = withContext(Dispatchers.IO) { images.savePhotos(uris) }
            if (_photos.value.isNotEmpty()) pinBuiltin(PHOTOS_TILE_KEY)
        }
    }

    // ----- Settings -----

    fun setAccent(index: Int) {
        _accent.value = index
        store.saveAccent(index)
    }

    fun setLiveTiles(enabled: Boolean) {
        _liveTiles.value = enabled
        store.saveLiveTiles(enabled)
    }

    fun setShowPreviews(enabled: Boolean) {
        _showPreviews.value = enabled
        store.saveShowPreviews(enabled)
    }

    fun setMoreTiles(enabled: Boolean) {
        val columns = if (enabled) 6 else 4
        _columns.value = columns
        store.saveColumns(columns)
    }

    fun setLightTheme(enabled: Boolean) {
        _lightTheme.value = enabled
        store.saveLightTheme(enabled)
    }

    override fun onCleared() {
        repo.unregisterCallback(packageCallback)
    }

    private companion object {
        const val NEW_APP_WINDOW_MS = 7L * 24 * 60 * 60 * 1000
        const val MAX_RECENT = 12
    }
}
